import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TestContact {

    TestContact(){

        String path = "";

        File test1 = new File("nelson_micheloud.txt");
        try {
            path = getPartContact(test1, 3);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File test2 = new File("jpgTest.jpg");
        try {
            path = getPartContact(test2, 3);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File test3 = new File("folderTest");
        try {
            path = getPartContact(test3, 3);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File test4 = new File("vgcfxdytaw637w48e59r6o87éouhjkbhvjcgh");
        try {
            path = getPartContact(test4, 3);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Test
    private String getPartContact(File contact, int idx) throws FileNotFoundException {
        String part = "";
        String next;
        int i = 0;

        Scanner s = new Scanner(contact);

        while(s.hasNext()){
            next = s.next();
            if (i == idx){
                part = next;
            }
            i++;
        }

        s.close();

        return part;
    }
}
