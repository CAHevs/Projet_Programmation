import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;


public class TestGallery {

    public TestGallery(){
        ImageIcon test1 = new ImageIcon();
        File monImage1 = new File("Test/jpgTest.jpg");
        test1 = getScaledImage((new ImageIcon(monImage1.getPath()).getImage()),110,110);

        ImageIcon test2 = new ImageIcon();
        File monImage2 = new File("Test/pngTest.png");
        test1 = getScaledImage((new ImageIcon(monImage2.getPath()).getImage()),110,110);

        ImageIcon test3 = new ImageIcon();
        File monImage3 = new File("Test/txtTest.txt");
        test1 = getScaledImage((new ImageIcon(monImage3.getPath()).getImage()),110,110);

        ImageIcon test4 = new ImageIcon();
        File monImage4 = new File("Test/folderTest");
        test1 = getScaledImage((new ImageIcon(monImage4.getPath()).getImage()),110,110);

    }





    @Test
    private ImageIcon getScaledImage(Image srcImg, int w, int h){
        Image img = srcImg;
        BufferedImage resizedImage = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImage.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImage);
}









}
