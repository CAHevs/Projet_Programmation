import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * La classe AlwaysOnDisplay qui extende de JFrame permet de simuler
 * l'écran de vérouillage optionnel du smartphone (Uniquement une horloge qui tourne)
 * @author Nelson Micheloud
 * @version 1.0
 * @since 04.06.2019
 */
public class AlwaysOnDisplay extends JFrame {

    private JPanel panelBottom = new JPanel();

    private ImageIcon onIcon = new ImageIcon("onIcon.PNG");
    private JButton on = new JButton(onIcon);

    /**
     * Constructueur de la classe AlwaysOnDisplay
     */
    AlwaysOnDisplay(){
        setUndecorated(true);
        setSize(480, 800);

        setBackground(Color.BLACK);
        getContentPane().setBackground(Color.BLACK);


        Clock clock = new Clock();
        add(clock, BorderLayout.CENTER);
        clock.start();

        SwitchOn switchOn = new SwitchOn();
        on.addActionListener(switchOn);

        on.setBorderPainted(false);
        on.setContentAreaFilled(false);
        on.setFocusPainted(false);
        on.setOpaque(false);

        panelBottom.setBackground(Color.BLACK);
        panelBottom.add(on);
        add(panelBottom, BorderLayout.SOUTH);
    }

    /**
     * La classe SwitchOn qui implémente ActionListener permet de passer
     * de AlwaysOnDisplay au LockScreen.
     */
    class SwitchOn implements ActionListener {
        /**
         * La méthode actionPerformed permet l'affichage du LockScreen et le dispose
         * du AlwaysOnDisplay.
         * @param e source de l'événement
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                LockScreen ls = new LockScreen();
                ls.setVisible(true);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            dispose();

        }
    }




}
