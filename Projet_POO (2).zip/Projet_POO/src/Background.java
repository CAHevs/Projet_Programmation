import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 *  La classe Background permet d'ajouter une image de background.
 *  Elle est utilisé dans la frame LockScreen.
 *
 * @author Nelson Micheloud
 * @version 1.0
 * @since 16-04-2019
 * @see LockScreen
 */
public class Background {

    private BufferedImage bg;
    private ImageIcon imagebg;

    /**
     * Constructeur de la classe Background.
     * On récupère une image fixe que l'on met dans un BufferedImage
     * et on met cette image dans un ImageIcon
     * @throws IOException on revoie une exception si le fichier n'exisite pas
     */
    public Background() throws IOException {
        bg = ImageIO.read(new File("background.jpg"));
        imagebg = new ImageIcon(bg);
    }

    /**
     * Cette méthode permet de retourner l'image qui sert
     * de background que l'on a définit de manière statique.
     * @return  L'image qui sert de backgroud
     */
    public ImageIcon getBackground(){
        return imagebg;
    }
}
