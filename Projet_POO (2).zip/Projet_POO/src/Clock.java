import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.swing.*;

/**
 * La classe Clock qui extend JLabel et implémente Runnable a pour but
 * d'afficher une horloge dans la frame AlwaysOnDisplay simulant l'écran
 * de vérouillage optionel du smartphone
 * @author Nelson Micheloud
 * @version 1.0
 * @since 03.06.2019
 */
public class Clock extends JLabel implements Runnable {

    private Thread thread = null;
    private SimpleDateFormat formatter = new SimpleDateFormat("s", Locale.getDefault());
    private Date currentDate;
    private int xcenter = 230, ycenter = 250, lastxs = 0, lastys = 0, lastxm = 0, lastym = 0, lastxh = 0,lastyh = 0; // coordonnées du centre et des extrémités des aiguilles
    private float piOn30 = (float) Math.PI / 30;
    private float piOn2 = (float) Math.PI / 2;

    /**
     * La méthode drawStructure permet de dessiner la structure de l'horlage
     * @param g  utilisé pour permettre les "dessins" de l'horloge
     */
    private void drawStructure(Graphics g){
        g.setFont(new Font("Berlin Sans FB Demi", Font.CENTER_BASELINE, 20));
        g.setColor(Color.lightGray);

        int size = 120;
        g.drawString("XII",((int) (Math.cos(0 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(0 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("°", ((int) (Math.cos(5 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(5 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("°", ((int) (Math.cos(10 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(10 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("III", ((int) (Math.cos(15 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(15 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("°", ((int) (Math.cos(20 *  piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(20 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("°", ((int) (Math.cos(25 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(25 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("VI", ((int) (Math.cos(30 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(30 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("°", ((int) (Math.cos(35 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(35 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("°", ((int) (Math.cos(40 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(40 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("IX", ((int) (Math.cos(45 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(45 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("°", ((int) (Math.cos(50 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(50 * piOn30 - piOn2) * size + ycenter))+10);
        g.drawString("°", ((int) (Math.cos(55 * piOn30 - piOn2) * size + xcenter))-10, ((int) (Math.sin(55 * piOn30 - piOn2) * size + ycenter))+10);

    }

    /**
     * La méthode paint permet de dessiner le reste de l'horloge
     * @param g utilisé pour permettre les "dessins" de l'horloge
     */
    public void paint(Graphics g) {
        int xhour, yhour, xminute, yminute, xsecond, ysecond, second, minute, hour;drawStructure(g);
        currentDate = new Date();
        formatter.applyPattern("s");
        second = Integer.parseInt(formatter.format(currentDate));
        formatter.applyPattern("m");
        minute = Integer.parseInt(formatter.format(currentDate));
        formatter.applyPattern("h");
        hour = Integer.parseInt(formatter.format(currentDate));
        xsecond = (int) (Math.cos(second * piOn30 - piOn2) * 120 + xcenter);
        ysecond = (int) (Math.sin(second * piOn30 - piOn2) * 120 + ycenter);
        xminute = (int) (Math.cos(minute * piOn30 - piOn2) * 100 + xcenter);
        yminute = (int) (Math.sin(minute * piOn30 - piOn2) * 100 + ycenter);
        xhour = (int) (Math.cos((hour * 30 + minute / 2) * 3.14f / 180 - 3.14f / 2) * 80 + xcenter);
        yhour = (int) (Math.sin((hour * 30 + minute / 2) * 3.14f / 180 - 3.14f / 2) * 80 + ycenter);

        // redessine les aiguilles lors
        g.setColor(Color.black);
        if (xsecond != lastxs || ysecond != lastys)
        {
            g.drawLine(xcenter, ycenter, lastxs, lastys);
        }
        if (xminute != lastxm || yminute != lastym)
        {
            g.drawLine(xcenter, ycenter - 1, lastxm, lastym);
            g.drawLine(xcenter - 1, ycenter, lastxm, lastym);
        }
        if (xhour != lastxh || yhour != lastyh)
        {
            g.drawLine(xcenter, ycenter - 1, lastxh, lastyh);
            g.drawLine(xcenter - 1, ycenter, lastxh, lastyh);
        }
        g.setColor(Color.green);
        g.drawLine(xcenter, ycenter, xsecond, ysecond);
        g.setColor(Color.lightGray);
        g.drawLine(xcenter, ycenter - 1, xminute, yminute);
        g.drawLine(xcenter - 1, ycenter, xminute, yminute);
        g.setColor(Color.lightGray);
        g.drawLine(xcenter, ycenter - 1, xhour, yhour);
        g.drawLine(xcenter - 1, ycenter, xhour, yhour);
        lastxs = xsecond;
        lastys = ysecond;
        lastxm = xminute;
        lastym = yminute;
        lastxh = xhour;
        lastyh = yhour;
    }

    /**
     * Permet de démarrer le Runnable afin que l'horloge se mette à jour
     */
    public void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }

    /**
     * Permet de stopper le Runnable afin que l'horloge se stop
     */
    public void stop()
    {

        thread = null;
    }

    /**
     * Méthode qui permet au code du Runnable de s'éxécuter après un certain temps
     */
    public void run() {
        while (thread != null) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
            }
            repaint();
        }
        thread = null;
    }
    /**
     * Méthode qui permet de réactuliser l'horloge
     * @param g utilisé pour permettre les "dessins" de l'horloge
     */
    public void update(Graphics g) {
        paint(g);
    }
}

