import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/**
 * La classe ConfirmSuppImg qui extends de JDialog permet
 * de supprimer l'image sélectionner. Elle fait office de
 * message de warning pour la confirmation ou l'annulation
 * @author Nelson Micheloud
 * @version 1.0
 * @since 20.05.2019
 */
public class ConfirmSuppImg extends JDialog {

    private JLabel supp = new JLabel("Voulez-vous supprimer cette image ?");
    private JPanel buttons = new JPanel();
    ImageIcon suppIcon = new ImageIcon("Bin.png");

    private JButton suppImg = new JButton(suppIcon);
    private JButton cancel = new JButton("Cancel");

    private Frame parentFrame;

    /**
     * Constructeur de la class ConfirmSuppImg
     * @param path Chemin de l'image qui sera supprimée ou non
     * @param gallery fenêtre parente
     * @param x position en x du JDialog
     * @param y position en y du JDialog
     * @param typeParentFrame permet de savoir si la suppression vient directement de la gallerie ou lors d'une
     *                        sélection d'une image précise
     */
    public ConfirmSuppImg(String path, Gallery gallery, int x, int y, String typeParentFrame){
        setUndecorated(true);
        setLocation(x, y);
        this.parentFrame = parentFrame;
        getRootPane().setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        getContentPane().setBackground(Color.BLACK);
        supp.setForeground(Color.WHITE);
        add(supp, BorderLayout.NORTH);

        Cancel cancelSupp = new Cancel(path, gallery, typeParentFrame);
        cancel.addActionListener(cancelSupp);
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.setFocusPainted(false);

        Suppress suppressImg = new Suppress(path, gallery);
        suppImg.addActionListener(suppressImg);
        suppImg.setContentAreaFilled(false);
        suppImg.setOpaque(false);


        buttons.add(cancel);
        buttons.add(suppImg);
        buttons.setBackground(Color.BLACK);
        add(buttons, BorderLayout.SOUTH);

        pack();
    }

    /**
     * Utilisation d'un JDialog en mode Modal pour permettre a la frame parente
     * d'attendre le temps de la sélection du choix de l'utilisateur
     * @return true
     */
    public boolean showModal(){
        setModal(true);
        setVisible(true);
        return true;
    }

    /**
     * La classe Cancel qui implémente ActionListener permet l'annulation
     * de la suppression de l'image.
     */
    class Cancel implements ActionListener {
        String path;
        Gallery gallery;
        String typeParentFrame;
        public Cancel(String path, Gallery gallery, String typeParentFrame){
            this.path = path;
            this.gallery = gallery;
            this.typeParentFrame = typeParentFrame;
        }
        public void actionPerformed(ActionEvent e){
            if(typeParentFrame == "gallery")
                dispose();
            else {
                try {
                    parentFrame = new ShowImage(path, gallery);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                parentFrame.setVisible(true);
                parentFrame.revalidate();
                dispose();
            }
        }
    }

    /**
     * La classe Suppress qui implémente ActionListener permet
     * de supprimer l'image
     */
    class Suppress implements ActionListener{
        Gallery gallery;
        String path;
        public Suppress(String path, Gallery gallery){
            this.gallery = gallery;
            this.path = path;

        }

        public void actionPerformed(ActionEvent e) {
            File file = new File(path);
            file.delete();

            gallery.dispose();

            try {
                parentFrame = new Gallery();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            parentFrame.setVisible(true);
            parentFrame.revalidate();
            dispose();
        }
    }

}
