import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Scanner;

/**
 * La classe ContactFrame qui extend JFrame est la frame correspondant à la liste de contact.
 * Depuis cette classe, on peut afficher un contact et l'éditer ou le supprimer via la classe ContactInfo.
 * On peut aussi ajouter un nouveau contact via la classe ContactInfo
 * @author Christopher Artero
 * @author Nelson Micheloud
 * @version 1.0
 * @since 13.05.2019
 */
public class ContactFrame extends JFrame {

    private PanelTop panelTop = new PanelTop();
    private JPanel contacts;
    private JScrollPane scrollPane;
    private File folder = new File("contact");
    private File[] listofContactsFile;
    private JButton[] listContacts;
    private ImageIcon addIcon = new ImageIcon("Add.png");
    private JButton addC = new JButton(addIcon);

    private ImageIcon homeIcon = new ImageIcon("Home.png");
    private ImageIcon backIcon = new ImageIcon("Back.png");

    protected JButton home = new JButton(homeIcon);
    protected JButton back = new JButton(backIcon);

    private JPanel panelBottom = new JPanel();

    private JPanel panelAddBottom = new JPanel();

    /**
     * Constructeur de la classe ContactFrame
     * @throws IOException on retourne une erreur dans le cas ou le fichier n'est pas trouvé
     */
    public ContactFrame() throws IOException {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(480,800);
        setUndecorated(true);
        getContentPane().setBackground(Color.BLACK);

        addContact addContact = new addContact(this);
        addC.addActionListener(addContact);
        addC.setFocusPainted(false);
        addC.setBackground(Color.BLACK);
        addC.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        addC.setPreferredSize(new Dimension(300, 60));

        contacts = contactList(folder);
        contacts.setLayout(new GridLayout(0,1));

        scrollPane = new JScrollPane(contacts);
        scrollPane.setBackground(Color.BLACK);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);
        panelBottom.add(home);
        panelBottom.add(back);
        panelBottom.setBackground(Color.BLACK);


        Back goBack = new Back();

        home.addActionListener(goBack);
        back.addActionListener(goBack);

        panelAddBottom.setLayout(new GridLayout(0,1));
        panelAddBottom.add(addC, BorderLayout.NORTH);
        panelAddBottom.add(panelBottom, BorderLayout.SOUTH);

        add(scrollPane, BorderLayout.CENTER);
        add(panelTop, BorderLayout.NORTH);

        add(panelAddBottom, BorderLayout.SOUTH);

    }

    /**
     * La méthode ContactList permet d'afficher tout les contacts contenu dans le dossier
     * passé en paramètre
     * @param folder dossier dans lequel se trouve les contacts
     * @return un JPanel avec tout les contactes
     * @throws FileNotFoundException on retourne une erreur dans le cas ou le fichier n'est pas trouvé
     */
    private JPanel contactList(File folder) throws FileNotFoundException {

        JPanel contacts = new JPanel();
        JPanel[] contactWithName;
        contacts.setBackground(Color.BLACK);

        listofContactsFile = getAllFileText(folder);

        listContacts = new JButton[listofContactsFile.length];
        contactWithName = new JPanel[listofContactsFile.length];

        for(int i = 0 ; i< listofContactsFile.length; i++){

            contactWithName[i] = new JPanel();

            listContacts[i] = new JButton();
            listContacts[i].setFont(new Font(Font.DIALOG ,Font.BOLD, 14));
            listContacts[i].setText(getNameFirstName(getContactName(listofContactsFile[i])));
            listContacts[i].setVerticalTextPosition(AbstractButton.CENTER);
            listContacts[i].setHorizontalTextPosition(AbstractButton.RIGHT);
            listContacts[i].addActionListener(new showContact(getContactName(listofContactsFile[i]), listofContactsFile[i], this));
            listContacts[i].setFocusPainted(false);
            listContacts[i].setBackground(Color.WHITE);
            listContacts[i].setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
            listContacts[i].setForeground(Color.BLACK);
            listContacts[i].setPreferredSize(new Dimension(440, 40));
            listContacts[i].setIcon(setIconContact(listofContactsFile[i]));

            contactWithName[i].add(listContacts[i]);
            contactWithName[i].setBackground(Color.BLACK);

            contacts.add(contactWithName[i]);
        }

        return contacts;
    }

    /**
     * La classe Back qui implémente ActionListener permet
     * de revenir en arrière dans le programme.
     * Cette ActionListener sera utilisé pour le bouton Back
     */
    class Back implements ActionListener {
        public void actionPerformed(ActionEvent e){
            MainFrame mf = null;
            try {
                mf = new MainFrame();
                mf.setVisible(true);

            } catch (IOException ex) {
                ex.printStackTrace();
            }
            dispose();
        }
    }
    /**
     * La méthode GetAllFileText permet de récupérer tout les fichiers
     * texte contenu dans le dossier passé en paramètre
     * @param folder dossier contenant les fichiers des contacts
     * @return un tableau de fichier avec tout les fichiers textes
     */
    private File[] getAllFileText(File folder){
        int nbTextFile = 0;
        String extension;
        int idx = 0;
        File[] allContacts = null;
        File[] listOfFiles = folder.listFiles();

        for (int i = 0; i<listOfFiles.length; i++){
            extension = getFileExtension(listOfFiles[i]);
            if(extension.equals("txt")){
                nbTextFile++;
            }
        }

        allContacts = new File[nbTextFile];

        for(int i = 0; i<listOfFiles.length; i++){
            if(getFileExtension(listOfFiles[i]).equals("txt")){
                allContacts[idx] = listOfFiles[i];
                idx++;
            }
        }

        return allContacts;
    }

    /**
     * La méthode GetFileExtension permet de récupérer l'extension
     * du fichier passé en paramètre
     * @param file fichier dont on veut l'extension
     * @return un string contenant l'extension du fichier
     */
    private String getFileExtension(File file){
        String name = file.getName();
        String extension = "";

        int lastIndexOf = name.lastIndexOf(".");
        if(lastIndexOf >= 0){
            extension = name.substring(lastIndexOf+1);
        }
        return extension;
    }

    /**
     * La méthode SetIconContact permet de définir l'image du contact qui
     * sera mise sur le JButton. Elle appelle la méthode GetImageContact() pour
     * pouvoir récupérer l'image.
     * @param file fichier du contact
     * @return l'image contenu dans le fichier du contact
     * @throws FileNotFoundException on retourne une erreur dans le cas ou le fichier n'est pas trouvé
     */
    private ImageIcon setIconContact(File file) throws FileNotFoundException {
        ImageIcon img = null;

        try{
            img = getScaledImage(new ImageIcon(getImageContact(file)),30,30);
        }catch(Exception e){
            img = getScaledImage(new ImageIcon("contact/default_icon.png"),30,30);
        }


        return img;
    }

    /**
     * La méthode GetImageContact permet de récupérer le chemin de l'image
     * lié au contact qui est contenu dans le fichier du contact.
     * @param contact le fichier du contact
     * @return un string contenant le chemin de l'image
     * @throws FileNotFoundException on retourne une erreur dans le cas ou le fichier n'est pas trouvé
     */
    private String getImageContact(File contact) throws FileNotFoundException {
        String path = "";

        path = getPartContact(contact, 3);

        return path;
    }

    /**
     * La méthode GetPartContact permet de récupérer une partie sélectionné contenu
     * dans le fichier contact.
     * @param contact le fichier du contact
     * @param idx l'index de la ligne que l'on veut récupérer
     * @return un string contenant la valeur que l'on a sélectionnée
     * @throws FileNotFoundException on retourne une erreur dans le cas ou le fichier n'est pas trouvé
     */
    private String getPartContact(File contact, int idx) throws FileNotFoundException {
        String part = "";
        String next;
        int i = 0;

        Scanner s = new Scanner(contact);

        while(s.hasNext()){
            next = s.next();
            if (i == idx){
                part = next;
            }
            i++;
        }

        s.close();

        return part;
    }

    /**
     * La méthode getScaledImage permet de redimensionner une image
     * afin qu'elle passe dans un bouton et que toutes les images aient la
     * même taille
     * @param srcImg Image de base qui sera redimensionnée
     * @param w largeur pour le redimensionnement
     * @param h hauteur pour le redimensionnement
     * @return un ImageIcon avec l'image redimensionnée
     */
    private ImageIcon getScaledImage(ImageIcon srcImg, int w, int h){
        Image img = srcImg.getImage();
        BufferedImage resizedImg = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImg.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImg);
    }

    /**
     * La méthode GetNameFirstName permet de récupérer le nom et le prénom
     * du contact en fonction d'un string contenant le nom directement issu du
     * nom de fichier du contact.
     * @param name le nom du fichier récupéré via la méthode GetContactName
     * @return le nom et le prénom sans "_"
     */
    private String getNameFirstName(String name){
        String nameFirstName;

        nameFirstName = name.substring(0, name.indexOf("_")) + " " + name.substring(name.indexOf("_") +1);

        return nameFirstName;
    }

    /**
     * La méthode GetContactName permet de récupérer le nom du contact
     * en fonction du nom du fichier.
     * @param file fichier dont on veut récupérer le nom
     * @return un string contenant le nom du contact sans l'extension du fichier
     */
    private String getContactName(File file){
        String contactName = "";

        contactName = file.getName().substring(file.getName().indexOf("/") + 1, file.getName().indexOf("."));

        return contactName;
    }

    /**
     * La classe ShowContact qui implémente Actionlistener permet
     * d'afficher un contact précis lors du clique sur le bouton
     * correspondant à ce dernier
     */
    public class showContact implements ActionListener{

        String name;
        Frame myFrame;
        File contactFile;

        public showContact(String contact, File contactFile, Frame myFrame){

            name = getNameFirstName(contact);
            this.contactFile = contactFile;
            this.myFrame = myFrame;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                ContactInfo contactInfo = new ContactInfo(contactFile, myFrame);
                contactInfo.setVisible(true);
                myFrame.dispose();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * La classe AddContact qui implémente ActionListener permet
     * lors du clique sur le bouton Add, d'ajouter un nouveau contact
     */
    public class addContact implements ActionListener{

        Frame myFrame;

        public addContact(Frame myFrame){
            this.myFrame = myFrame;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            myFrame.dispose();
            if (e.getSource() == addC){
                ContactInfo contactInfo = null;
                try {
                    contactInfo = new ContactInfo(myFrame);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                boolean ok = contactInfo.showModal();
                if(ok==true){
                    try {
                        contacts = contactList(folder);
                    } catch (FileNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
                contactInfo.dispose();
            }
        }
    }
}
