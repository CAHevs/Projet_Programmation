import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.metal.MetalSliderUI;
import java.awt.*;
import java.io.IOException;

/**
 *  LockScreen est une classe qui extends JFrame. Elle est la
 *  première frame que l'utilisateur voit lors du lancement
 *  de l'application.
 *  Le JSlider permet de dévérouiller le smartphone et de passer à la mainFrame
 * @author  Christopher Artero
 * @author  Nelson Micheloud
 * @version 1.0
 * @since   16-04-2019
 */
public class LockScreen extends JFrame {

    private Background myBG = new Background();
    private JLabel background = new JLabel();
    private JSlider unlock = new JSlider();
    private JPanel panelUnlock = new JPanel();
    private PanelTop panelTop = new PanelTop();
    Icon icon = new ImageIcon("slider_thumb.png");
    UIDefaults defaults = UIManager.getDefaults();

    /**
     * Constructeur de la frame LockScreen. Cette frame contient
     * un panel top de type PanelTop, un label contenant le background
     * et un slider pour simuler l'action de dévérouiller le téléphone
     * @throws IOException retourne une exception si une image n'est pas trouvée
     */
    public LockScreen() throws IOException {

        setSize(480,800);
        setUndecorated(true);

        defaults.put("Slider.horizontalThumbIcon", icon);

        background.setIcon(myBG.getBackground());

        add(background);

        unlock.setValue(0);
        unlock.addChangeListener(new Unlock());
        unlock.setOpaque(false);
        unlock.setUI(new MetalSliderUI());

        unlock.setBackground(Color.darkGray);
        unlock.setForeground(Color.lightGray);
        unlock.setPaintTrack(false);

        panelUnlock.add(unlock);
        panelUnlock.setBackground(Color.BLACK);

        add(panelTop, BorderLayout.NORTH);
        add(panelUnlock, BorderLayout.SOUTH);
    }
    /**
     *  La class Unlock qui implémente ChangeListener a pour
     *  but de récupérer la valeur du JSlider afin que
     *  lorsqu'il atteigne la valeur 100, on dispose
     *  la frame LockScreen et on affiche la frame MainFrame
     */
    public class Unlock implements ChangeListener {

        @Override
        public void stateChanged(ChangeEvent e) {
            if (e.getSource() == unlock){
                if (!unlock.getValueIsAdjusting()){
                    unlock.setValue(0);
                }
                if (unlock.getValue()== 100){
                    MainFrame mf = null;
                    try {
                        mf = new MainFrame();
                        mf.setVisible(true);
                        disposeWindow();

                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }
    /**
     *  Cette méthode permet de dispose la frame LockScreen
     */
    private void disposeWindow(){
        this.setVisible(false);
    }
}
