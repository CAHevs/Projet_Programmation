import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Date;

/**
 * La classe ShowImage qui extend JFrame permet d'afficher une image sélectionner
 * dans la gallerie en grand.
 * @author Nelson Micheloud
 * @version 1.0
 * @since 27.05.2019
 */
public class ShowImage extends JFrame {

    private PanelTop panelTop = new PanelTop();
    private String filename;
    private ImageIcon img;
    private JButton doSmthImage;


    private JPanel panelBottom = new JPanel();

    private ImageIcon homeIcon = new ImageIcon("Home.png");
    private ImageIcon backIcon = new ImageIcon("Back.png");

    private JButton home = new JButton(homeIcon);
    private JButton back = new JButton(backIcon);

    private Frame parentFrame;

    /**
     * Constructeur de la classe ShowImage
     * @param path Chemin de l'image
     * @param gallery fenêtre parente
     * @throws IOException on retourne une erreur dans le cas ou le fichier n'est pas trouvé
     */
    public ShowImage(String path, Gallery gallery) throws IOException {
        setSize(480,800);
        setUndecorated(true);


        parentFrame = gallery;
        filename = path;
        ImageIcon imgIcon = new ImageIcon(filename);
        double w = imgIcon.getIconWidth();
        double h = imgIcon.getIconHeight();
        double newW, newH;
        double x, y, newDim; // x = ratio de w/480 et y = ratio de h/700

        x = w / 480;
        y = h / 720;


        if(w>h){

            newH = h / x;
            img = getScaledImage(imgIcon.getImage(),480,(int)newH);
        }
        else{
            newW = w/y;

            if(newW<480) {

                img = getScaledImage(imgIcon.getImage(), (int) newW, 720);
            }
            else{
                newH = h/x;
                img = getScaledImage(imgIcon.getImage(),480,(int)newH);
            }

        }

        doSmthImage = new JButton(img);

        Suppress suppImg = new Suppress(path, gallery);
        doSmthImage.addMouseListener(suppImg);

        add(panelTop, BorderLayout.NORTH);
        doSmthImage.setForeground(Color.BLACK);
        add(doSmthImage);

        doSmthImage.setBorderPainted(false);
        //doSmthImage.setContentAreaFilled(false);
        doSmthImage.setFocusPainted(false);
        //doSmthImage.setOpaque(false);
        doSmthImage.setBackground(Color.BLACK);

        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Back goBack = new Back();
        Home goHome = new Home(parentFrame);

        home.addActionListener(goHome);
        back.addActionListener(goBack);

        panelBottom.add(home);
        panelBottom.add(back);
        panelBottom.setBackground(Color.BLACK);

        add(panelBottom, BorderLayout.SOUTH);

    }

    /**
     * La méthode getScaledImage permet de redimensionner une image
     * afin qu'elle passe dans un bouton et que toutes les images aient la
     * même taille
     * @param srcImg Image de base qui sera redimensionnée
     * @param w largeur pour le redimensionnement
     * @param h hauteur pour le redimensionnement
     * @return un ImageIcon avec l'image redimensionnée
     */
    private ImageIcon getScaledImage(Image srcImg, int w, int h){
        Image img = srcImg;
        BufferedImage resizedImage = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImage.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImage);
    }

    /**
     * La classe Back qui implémente ActionListener permet
     * de revenir en arrière dans le programme.
     */
    class Back implements ActionListener {

        public void actionPerformed(ActionEvent e){

            dispose();

        }
    }
    /**
     * La classe Home qui implémente ActionListener permet de
     * revenir à la MainFrame
     */
    class Home implements ActionListener {
        Frame parentFrame;

        public Home(Frame parentFrame){
            this.parentFrame = parentFrame;
        }

        @Override
        public void actionPerformed(ActionEvent e) {

            dispose();
            parentFrame.dispose();

            try {
                MainFrame mf = new MainFrame();
                mf.setVisible(true);

            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * La classe Suppress qui implémente MouseListener permet
     * de supprimer l'image en fonction du temps passé avec le clique de la
     * souris sur l'image
     */
    class Suppress implements MouseListener {

        String path;
        Gallery gallery;
        public Suppress(String path, Gallery gallery){
            this.path = path;
            this.gallery = gallery;
        }

        Date pressedTime;
        long timeClicked;

        @Override
        public void mouseClicked(MouseEvent e) {
        }

        @Override
        public void mousePressed(MouseEvent e) {
            pressedTime = new Date();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            timeClicked = new Date().getTime() - pressedTime.getTime();
            if (timeClicked > 1000) {
                String typeParentFrame = "showImage";
                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                if(x>270)
                    x=270;
                ConfirmSuppImg confirm = new ConfirmSuppImg(path, gallery, x, y, typeParentFrame);
                if(confirm.showModal())
                    dispose();
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

    }

}