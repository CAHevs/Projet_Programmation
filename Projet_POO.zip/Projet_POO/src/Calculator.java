import javax.swing.*;

public class Calculator extends JFrame {
    private JPanel screen = new JPanel();
    private JPanel buttons = new JPanel();

}
