import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class ConfirmSuppImg extends JDialog {

    private JLabel supp = new JLabel("Voulez-vous supprimer cette image ?");
    private JPanel buttons = new JPanel();
    ImageIcon suppIcon = new ImageIcon("Bin.png");

    private JButton suppImg = new JButton(suppIcon);
    private JButton cancel = new JButton("Cancel");

    private Frame parentFrame;


    public ConfirmSuppImg(String path, Gallery gallery){
        this.parentFrame = parentFrame;


        add(supp, BorderLayout.NORTH);

        Cancel cancelSupp = new Cancel();
        cancel.addActionListener(cancelSupp);

        Suppress suppressImg = new Suppress(path, gallery);
        suppImg.addActionListener(suppressImg);

        buttons.add(cancel);
        buttons.add(suppImg);
        add(buttons, BorderLayout.SOUTH);

        pack();
    }


    public boolean showModal(){
        setModal(true);
        setVisible(true);
        return true;
    }

    class Cancel implements ActionListener {
        public void actionPerformed(ActionEvent e){

            dispose();
        }
    }

    class Suppress implements ActionListener{
        Gallery gallery;
        String path;
        public Suppress(String path, Gallery gallery){
            this.gallery = gallery;
            this.path = path;
        }

        public void actionPerformed(ActionEvent e) {
            File file = new File(path);
            file.delete();

            gallery.dispose();

            try {
                parentFrame = new Gallery();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            parentFrame.setVisible(true);
            parentFrame.revalidate();
            dispose();
        }
    }

}
