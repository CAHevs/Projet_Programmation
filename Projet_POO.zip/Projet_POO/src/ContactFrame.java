import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Scanner;

public class ContactFrame extends JFrame {

    private PanelTop panelTop = new PanelTop();
    private JPanel contacts;
    private JScrollPane scrollPane;
    private File folder = new File("contact");
    private File[] listofContactsFile;
    private JButton[] listContacts;
    private JButton addC = new JButton("Add");

    private JPanel home_back = new JPanel();

    private JPanel panelBottom = new JPanel(new GridLayout(0,1));

    private ImageIcon homeIcon = new ImageIcon("Home.png");
    private ImageIcon backIcon = new ImageIcon("Back.png");

    private JButton home = new JButton(homeIcon);
    private JButton back = new JButton(backIcon);

    public ContactFrame() throws IOException {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(480,800);
        setUndecorated(true);

        addContact addContact = new addContact(this);
        addC.addActionListener(addContact);

        contacts = contactList(folder);
        contacts.setLayout(new MigLayout());


        scrollPane = new JScrollPane(contacts);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        add(scrollPane, BorderLayout.CENTER);
        add(panelTop, BorderLayout.NORTH);
        add(addC, BorderLayout.SOUTH);

        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Back goBack = new Back();

        home.addActionListener(goBack);
        back.addActionListener(goBack);


        home_back.add(home);
        home_back.add(back);

        panelBottom.add(addC, BorderLayout.NORTH);
        panelBottom.add(home_back, BorderLayout.SOUTH);
        home_back.setBackground(Color.BLACK);

        add(panelBottom, BorderLayout.SOUTH);


    }

    private JPanel contactList(File folder) throws FileNotFoundException {

        JPanel contacts = new JPanel();
        JPanel[] contactWithName;

        listofContactsFile = getAllFileText(folder);

        listContacts = new JButton[listofContactsFile.length];
        contactWithName = new JPanel[listofContactsFile.length];

        for(int i = 0 ; i< listofContactsFile.length; i++){

            contactWithName[i] = new JPanel();

            listContacts[i] = new JButton();
            listContacts[i].setFont(new Font(Font.DIALOG ,Font.BOLD, 14));
            listContacts[i].setText(getNameFirstName(getContactName(listofContactsFile[i])));
            listContacts[i].setVerticalTextPosition(AbstractButton.CENTER);
            listContacts[i].setHorizontalTextPosition(AbstractButton.RIGHT);
            listContacts[i].addActionListener(new showContact(getContactName(listofContactsFile[i]), listofContactsFile[i], this));
            listContacts[i].setBorderPainted(false);
            listContacts[i].setContentAreaFilled(false);
            listContacts[i].setFocusPainted(false);
            listContacts[i].setOpaque(false);
            listContacts[i].setIcon(setIconContact(listofContactsFile[i]));

            contactWithName[i].add(listContacts[i]);

            contacts.add(contactWithName[i], "wrap");
        }

        return contacts;
    }

    class Back implements ActionListener {
        public void actionPerformed(ActionEvent e){

            dispose();
        }
    }

    private File[] getAllFileText(File folder){
        int nbTextFile = 0;
        String extension;
        int idx = 0;
        File[] allContacts = null;
        File[] listOfFiles = folder.listFiles();

        for (int i = 0; i<listOfFiles.length; i++){
            extension = getFileExtension(listOfFiles[i]);
            if(extension.equals("txt")){
                nbTextFile++;
            }
        }

        allContacts = new File[nbTextFile];

        for(int i = 0; i<listOfFiles.length; i++){
            if(getFileExtension(listOfFiles[i]).equals("txt")){
                allContacts[idx] = listOfFiles[i];
                idx++;
            }
        }

        return allContacts;
    }

    private String getFileExtension(File file){
        String name = file.getName();
        String extension = "";

        int lastIndexOf = name.lastIndexOf(".");
        if(lastIndexOf >= 0){
            extension = name.substring(lastIndexOf+1);
        }
        return extension;
    }

    private ImageIcon setIconContact(File file) throws FileNotFoundException {
        ImageIcon img = getScaledImage(new ImageIcon(getImageContact(file)),30,30);

        return img;
    }

    private String getImageContact(File contact) throws FileNotFoundException {
        String path = "";

        path = getPartContact(contact, 3);

        return path;
    }

    private String getPartContact(File contact, int idx) throws FileNotFoundException {
        String part = "";
        String next;
        int i = 0;

        Scanner s = new Scanner(contact);

        while(s.hasNext()){
            next = s.next();
            if (i == idx){
                part = next;
            }
            i++;
        }

        s.close();

        return part;
    }

    private ImageIcon getScaledImage(ImageIcon srcImg, int w, int h){
        Image img = srcImg.getImage();
        BufferedImage resizedImg = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImg.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImg);
    }

    private String getNameFirstName(String name){
        String nameFirstName;

        nameFirstName = name.substring(0, name.indexOf("_")) + " " + name.substring(name.indexOf("_") +1);

        return nameFirstName;
    }

    private String getContactName(File file){
        String contactName = "";

        contactName = file.getName().substring(file.getName().indexOf("/") + 1, file.getName().indexOf("."));

        return contactName;
    }

    public class showContact implements ActionListener{

        String name;
        Frame myFrame;
        File contactFile;

        public showContact(String contact, File contactFile, Frame myFrame){

            name = getNameFirstName(contact);
            this.contactFile = contactFile;
            this.myFrame = myFrame;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                ContactInfo contactInfo = new ContactInfo(contactFile, myFrame);
                contactInfo.setVisible(true);
                myFrame.dispose();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public class addContact implements ActionListener{

        Frame myFrame;

        public addContact(Frame myFrame){
            this.myFrame = myFrame;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            myFrame.dispose();
            if (e.getSource() == addC){
                ContactInfo contactInfo = null;
                try {
                    contactInfo = new ContactInfo(myFrame);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                boolean ok = contactInfo.showModal();
                if(ok==true){
                    try {
                        contacts = contactList(folder);
                    } catch (FileNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
                contactInfo.dispose();
            }
        }
    }
}
