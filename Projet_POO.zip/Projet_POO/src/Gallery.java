import net.miginfocom.swing.MigLayout;
import org.apache.commons.io.FileUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Gallery extends JFrame {

    private PanelTop panelTop = new PanelTop();
    private JPanel galleryPanel = new JPanel();
    private JPanel home_back = new JPanel();



    ImageIcon addIcon = new ImageIcon("images/add.png");

    private JButton addButton = new JButton(addIcon);
    private JPanel add = new JPanel();


    private JPanel panelBottom = new JPanel(new GridLayout(0,1));

    private ImageIcon homeIcon = new ImageIcon("HomeIcon.png");
    private ImageIcon backIcon = new ImageIcon("backIcon.png");

    private JButton home = new JButton(homeIcon);
    private JButton back = new JButton(backIcon);

    int nbImage = 0;

    private File folder = new File("images");
    private File[] listAllImages;

    public Gallery() throws IOException {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(480, 800);
        setUndecorated(true);

        galleryPanel.setLayout(new MigLayout());

        listAllImages = getAllImage(folder);


        JButton[] tButton = new JButton[nbImage];

        for(int i = 0; i<nbImage; i++){
            tButton[i] = new JButton();
            tButton[i].setIcon(getScaledImage(new ImageIcon(listAllImages[i].getPath()).getImage(),70,70));
            tButton[i].addActionListener(new OpenImg(listAllImages[i].getPath()));
            tButton[i].setContentAreaFilled(false);

            if((i+1)%4 == 0)
                galleryPanel.add(tButton[i], "wrap");
            else
                galleryPanel.add(tButton[i]);
        }


        add(panelTop, BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(galleryPanel);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);


        addButton.addActionListener(new addNewImage());

        add.add(addButton);

        add(scroll, BorderLayout.CENTER);


        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Gallery.Back goBack = new Gallery.Back();

        home.addActionListener(goBack);
        back.addActionListener(goBack);


        home_back.add(home);
        home_back.add(back);

        panelBottom.add(add, BorderLayout.NORTH);
        panelBottom.add(home_back, BorderLayout.SOUTH);
        setBackground(Color.GRAY);

        add(panelBottom, BorderLayout.SOUTH);



    }

    private File[] getAllImage(File folder){
        File[] listImages = folder.listFiles();

        nbImage = listImages.length;

        return listImages;
    }

    private ImageIcon getScaledImage(Image srcImg, int w, int h){
        Image img = srcImg;
        BufferedImage resizedImage = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImage.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImage);
    }


    class Back implements ActionListener {
        public void actionPerformed(ActionEvent e){
            dispose();
        }
    }


    class OpenImg implements ActionListener {
        String path;
        public OpenImg(String path){
            this.path = path;
        }
        public void actionPerformed(ActionEvent e) {
            ShowImage image = null;

            try {
                image = new ShowImage(path);

            } catch (IOException e1) {
                e1.printStackTrace();
            }
            image.setVisible(true);
        }
    }


    class addNewImage implements  ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                addImage();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    private void addImage() throws IOException {
        JFileChooser fc = new JFileChooser();
        File source ;
        File dest ;

        fc.showOpenDialog(this);
        source = new  File(String.valueOf(fc.getSelectedFile()));
        dest = new File("images/"+source.getName());

        FileUtils.copyFile(source, dest);
        dispose();
        setVisible(true);
    }


}
