import net.miginfocom.swing.MigLayout;
import org.apache.commons.io.FileUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Date;

public class Gallery extends JFrame {

    private PanelTop panelTop = new PanelTop();
    private JPanel galleryPanel = new JPanel();
    private JPanel home_back = new JPanel();



    ImageIcon addIcon = new ImageIcon("add.png");

    private JButton addButton = new JButton(addIcon);

    private JPanel panelBottom = new JPanel(new GridLayout(0,1));

    private ImageIcon homeIcon = new ImageIcon("HomeIcon.png");
    private ImageIcon backIcon = new ImageIcon("backIcon.png");

    private JButton home = new JButton(homeIcon);
    private JButton back = new JButton(backIcon);

    int nbImage = 0;

    private File folder = new File("images");
    private File[] listAllImages;

    private Frame parentFrame;


    public Gallery() throws IOException {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(480, 800);
        setUndecorated(true);
        this.parentFrame = parentFrame;

        galleryPanel.setLayout(new MigLayout());

        listAllImages = getAllImage(folder);


        JButton[] tButton = new JButton[nbImage];

        for(int i = 0; i<nbImage; i++){
            tButton[i] = new JButton();
            tButton[i].setIcon(getScaledImage(new ImageIcon(listAllImages[i].getPath()).getImage(),70,70));
            tButton[i].addMouseListener(new DoSmthImg(listAllImages[i].getPath(), this));
            tButton[i].setContentAreaFilled(false);

            if((i+1)%4 == 0)
                galleryPanel.add(tButton[i], "wrap");
            else
                galleryPanel.add(tButton[i]);
        }


        add(panelTop, BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(galleryPanel);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);


        addButton.addActionListener(new addNewImage());


        add(scroll, BorderLayout.CENTER);


        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Back goBack = new Back();

        home.addActionListener(goBack);
        back.addActionListener(goBack);


        home_back.add(home);
        home_back.add(back);

        panelBottom.add(addButton, BorderLayout.NORTH);
        panelBottom.add(home_back, BorderLayout.SOUTH);
        setBackground(Color.GRAY);

        add(panelBottom, BorderLayout.SOUTH);



    }

    private File[] getAllImage(File folder){
        File[] listImages = folder.listFiles();

        nbImage = listImages.length;

        return listImages;
    }

    private ImageIcon getScaledImage(Image srcImg, int w, int h){
        Image img = srcImg;
        BufferedImage resizedImage = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImage.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImage);
    }


    class Back implements ActionListener {
        public void actionPerformed(ActionEvent e){

            dispose();
        }
    }

/*
    class OpenImg implements ActionListener {
        String path;
        public OpenImg(String path){
            this.path = path;
        }
        public void actionPerformed(ActionEvent e) {
            ShowImage image = null;

            try {
                image = new ShowImage(path);

            } catch (IOException e1) {
                e1.printStackTrace();
            }
            image.setVisible(true);
        }
    }
*/


    class addNewImage implements  ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                addImage();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }


    private void addImage() throws IOException {
        JFileChooser fc = new JFileChooser();
        File source ;
        File dest ;

        fc.showOpenDialog(this);
        source = new  File(String.valueOf(fc.getSelectedFile()));
        dest = new File("images/"+source.getName());

        FileUtils.copyFile(source, dest);

        try {
            parentFrame = new Gallery();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        parentFrame.setVisible(true);
        parentFrame.revalidate();
        dispose();

        dispose();

    }

    public void showImage(String path, Gallery gallery) {
        ShowImage image = null;

        try {
            image = new ShowImage(path, gallery);

        } catch (IOException e1) {
            e1.printStackTrace();
        }
        image.setVisible(true);
    }


    class DoSmthImg implements MouseListener {

        String path;
        Gallery gallery;
        public DoSmthImg(String path, Gallery gallery){
            this.path = path;
            this.gallery = gallery;
        }

        Date pressedTime;
        long timeClicked;

        @Override
        public void mouseClicked(MouseEvent e) {
        }

        @Override
        public void mousePressed(MouseEvent e) {
            pressedTime = new Date();

        }

        @Override
        public void mouseReleased(MouseEvent e) {
            timeClicked = new Date().getTime() - pressedTime.getTime();
            if (timeClicked > 1000) {
                ConfirmSuppImg confirm = new ConfirmSuppImg(path, gallery);
                confirm.setVisible(true);

            }
            else {
            showImage(path, gallery);
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

    }
}
