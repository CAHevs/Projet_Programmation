import javax.swing.*;
import java.io.IOException;




public class GooglePage extends JFrame {



    GooglePage() throws IOException {


        JEditorPane website = new JEditorPane("http://www.google.com/");
        website.setEditable(false);


        setSize(480, 800);

        add(new JScrollPane(website));
    }
}
