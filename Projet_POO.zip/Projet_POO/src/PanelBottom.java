import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelBottom extends JPanel {

   /* private ImageIcon homeIcon = new ImageIcon("HomeIcon.png");
    private ImageIcon backIcon = new ImageIcon("backIcon.png");

    private JButton home = new JButton(homeIcon);
    private JButton back = new JButton(backIcon);


    public PanelBottom(){

        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);



        add(home);
        add(back);
        setBackground(Color.GRAY);

    }


*/

}
