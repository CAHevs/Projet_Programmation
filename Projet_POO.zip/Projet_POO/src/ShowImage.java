import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class ShowImage extends JFrame {

    private PanelTop panelTop = new PanelTop();
    private String filename;
    private ImageIcon img;
    private JLabel lblImage;


    private PanelBottom panelBottom = new PanelBottom();

    private ImageIcon homeIcon = new ImageIcon("HomeIcon.png");
    private ImageIcon backIcon = new ImageIcon("backIcon.png");

    private JButton home = new JButton(homeIcon);
    private JButton back = new JButton(backIcon);


    public ShowImage(String path) throws IOException {
        setSize(480,800);
        setUndecorated(true);

        filename = path;
        ImageIcon imgIcon = new ImageIcon(filename);
        int w = imgIcon.getIconWidth();
        int h = imgIcon.getIconHeight();
        double x, newDim;


        if(w > h){
            x = w / 480;
            newDim = h / x;
            img = getScaledImage(imgIcon.getImage(),480,(int)newDim);
        }
        else{
            x = h / 700;
            newDim = w / x;
            img = getScaledImage(imgIcon.getImage(),(int)newDim,700);
        }





        lblImage = new JLabel(img);


        add(panelTop, BorderLayout.NORTH);
        lblImage.setForeground(Color.BLACK);
        add(lblImage);


        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Back goBack = new Back();
        back.addActionListener(goBack);

        panelBottom.add(home);
        panelBottom.add(back);
        panelBottom.setBackground(Color.GRAY);

        add(panelBottom, BorderLayout.SOUTH);

    }

    private ImageIcon getScaledImage(Image srcImg, int w, int h){
        Image img = srcImg;
        BufferedImage resizedImage = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImage.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImage);
    }

    public ShowImage() throws IOException {
    }

    class Back implements ActionListener {

        public void actionPerformed(ActionEvent e){

            dispose();

        }
    }

    class Home implements ActionListener {

        public void actionPerformed(ActionEvent e){

            dispose();


        }
    }

}