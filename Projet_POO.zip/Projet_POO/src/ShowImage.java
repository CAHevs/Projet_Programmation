import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Date;

public class ShowImage extends JFrame {

    private PanelTop panelTop = new PanelTop();
    private String filename;
    private ImageIcon img;
    private JButton doSmthImage;


    private PanelBottom panelBottom = new PanelBottom();

    private ImageIcon homeIcon = new ImageIcon("HomeIcon.png");
    private ImageIcon backIcon = new ImageIcon("backIcon.png");

    private JButton home = new JButton(homeIcon);
    private JButton back = new JButton(backIcon);


    public ShowImage(String path, Gallery gallery) throws IOException {
        setSize(480,800);
        setUndecorated(true);

        filename = path;
        ImageIcon imgIcon = new ImageIcon(filename);
        int w = imgIcon.getIconWidth();
        int h = imgIcon.getIconHeight();
        double x, newDim;


        if(w > h){
            x = w / 480;
            newDim = h / x;
            img = getScaledImage(imgIcon.getImage(),480,(int)newDim);
        }
        else{
            x = h / 700;
            newDim = w / x;
            img = getScaledImage(imgIcon.getImage(),(int)newDim,700);
        }

        doSmthImage = new JButton(img);

        Suppress suppImg = new Suppress(path, gallery);
        doSmthImage.addMouseListener(suppImg);

        add(panelTop, BorderLayout.NORTH);
        doSmthImage.setForeground(Color.BLACK);
        add(doSmthImage);


        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Back goBack = new Back();
        back.addActionListener(goBack);

        panelBottom.add(home);
        panelBottom.add(back);
        panelBottom.setBackground(Color.GRAY);

        add(panelBottom, BorderLayout.SOUTH);

    }


    private ImageIcon getScaledImage(Image srcImg, int w, int h){
        Image img = srcImg;
        BufferedImage resizedImage = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImage.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImage);
    }

    public ShowImage() throws IOException {
    }

    class Back implements ActionListener {

        public void actionPerformed(ActionEvent e){

            dispose();

        }
    }

    class Home implements ActionListener {

        public void actionPerformed(ActionEvent e){

            dispose();


        }
    }

    class Suppress implements MouseListener {

        String path;
        Gallery gallery;
        public Suppress(String path, Gallery gallery){
            this.path = path;
            this.gallery = gallery;
        }

        Date pressedTime;
        long timeClicked;

        @Override
        public void mouseClicked(MouseEvent e) {
        }

        @Override
        public void mousePressed(MouseEvent e) {
            pressedTime = new Date();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            timeClicked = new Date().getTime() - pressedTime.getTime();
            if (timeClicked > 1500) {
                ConfirmSuppImg confirm = new ConfirmSuppImg(path, gallery);
                if(confirm.showModal())
                    dispose();
            }

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

    }

}