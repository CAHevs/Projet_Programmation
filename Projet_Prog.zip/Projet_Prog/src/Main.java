import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        LockScreen lockScreen = new LockScreen();
        lockScreen.setVisible(true);

        //ContactFrame contact = new ContactFrame();
        //contact.setVisible(true);

        //PixelArtGame game = new PixelArtGame();
        //game.setVisible(true);
    }
}
