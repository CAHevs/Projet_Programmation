import javax.swing.*;

public class PanelMain extends JPanel {
}
