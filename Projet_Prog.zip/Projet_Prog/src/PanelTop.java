/* *************************************************** */
// Réalisée par : Christopher Artero
// Le : 17.04.2019
// Cette classe permet de créer un modèl pour le JPanel
// du top qui sera toujours le même dans tout le projet.
// Ce dernier contient l'heure actuel de la machine ainsi
// que le niveau de batterie de cette dernière.
/* *************************************************** */

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;

public class PanelTop extends JPanel {

    private JLabel batteryDisplay = new JLabel();   // Label pour afficher l'image du niveau de batterie
    private JLabel percentDisplay = new JLabel();   // Label pour afficher le pourcentagde du niveau de batterie
    private JLabel battery = new JLabel("",SwingConstants.RIGHT); // Label affichant l'image du niveau de batterie
    private JLabel time = new JLabel("", SwingConstants.CENTER);  // Label affichage l'heure actuel de la machine
    private JLabel fiveG = new JLabel("5G", SwingConstants.LEFT); // Label affichant 5G
    private Timer timer_time;   // Timer permettant d'actualiser l'heure et le pourcentage de batterie

    // String pour permettre le traitement des infos de la machine physique
    private String info_battery, percentBatteryText, statusBattery, percentBatteryWithoutSymbol;
    private int valuePercent;   // Entier pour récupérer le pourcentage de la batterie
    private BufferedImage img;  // Image qui sera lu dans le dossier Battery a la racine du projet

    public PanelTop() throws IOException {

        // Définition du layout pour avoir 3 colonnes
        this.setLayout(new GridLayout(1,3));

        // Instanciation de l'action du timer
        Task_timer task_timer = new Task_timer();
        // Définition de l'action que le timer va effectuer avec un délay de 100 ms
        timer_time = new Timer(100, task_timer);
        // Activation de la répétition du timer
        timer_time.setRepeats(true);
        // Activation du timer a proprement parler
        timer_time.start();

        // Appel de la méthode DisplayBatteryLevel
        DisplayBatteryLevel();

        // Définition du background du panel en noir
        this.setBackground(Color.BLACK);
        // Définition de la couleur du texte du label percentDisplay en blanc
        percentDisplay.setForeground(Color.white);
        // Définition de la couleur du texte du label fiveG en blanc
        fiveG.setForeground(Color.white);
        // Définition de la couleur du texte du label time en blanc
        time.setForeground(Color.white);
        // Ajout du label fiveG et du label time au panel top
        this.add(fiveG);
        this.add(time);
        // Défintion de la couleur du texte pour le label battery en blanc
        battery.setForeground(Color.white);
        // Définition de l'icone pour le label battery via la méthode getIcon
        battery.setIcon(batteryDisplay.getIcon());
        // Définition du texte du label battery via la méthode getText du label percentDisplay
        battery.setText(percentDisplay.getText());
        // Ajout du label battery au panel
        this.add(battery);
    }


    public class Task_timer implements ActionListener{
    /*
    Le but du timer est que chaque 100 ms, on revalide
    l'heure du système affiché, ainsi que l'image correspondante
    au niveau de batterie et son pourcentage
     */
        @Override
        public void actionPerformed(ActionEvent e) {
            // L'utilisation du try and catch est nécessaire car on cherche une image stocké dans un dossier
            try {
                // Appel de la méthode DisplayBatteryLevel
                DisplayBatteryLevel();
                // Ajout au label battery l'icon du label batteryDisplay
                battery.setIcon(batteryDisplay.getIcon());
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            // Définition du texte pour le label time en appelant la méthode getCurrentTime
            time.setText(getCurrentTime());
        }
    }

    private String getCurrentTime(){
        /*
        Cette méthode permet de récupérer l'heure actuel de la machine en utilisation
        un objet de type Calendar et en travail sur le format de l'heure affichée.
        Elle retourne un objet de type string qui sera l'heure à affichée.
         */
        // String contenant l'heure actuel de la machine qui sera retourné
        String currentTime = "";
        // Création d'un objet de type Calendar et récupérant l'instance de la machine
        Calendar time = Calendar.getInstance();

        // Si l'heure du calendrier est inférieur à 10
        if(time.get(Calendar.HOUR_OF_DAY)<10){
            // Si la minute du calendrier est inférieur à 10
            if (time.get(Calendar.MINUTE) < 10){
                // Ajout d'un 0 devant le chiffre des heures ansi que d'un 0 devant les minutes
                // Récupération du string modifié et formaté dans le String currentTime
                currentTime = "0"+time.get(Calendar.HOUR_OF_DAY) + "h0" + time.get(Calendar.MINUTE);
            }
            // Dans le cas ou la minute du calendrier n'est pas inférieur à 10
            else{
                // Ajout d'une 0 devant le chiffre des heures
                currentTime = "0"+time.get(Calendar.HOUR_OF_DAY) + "h" + time.get(Calendar.MINUTE);
            }
        }
        // Dans le cas ou l'heure du calendrier n'est pas inférieur à 10
        else{
            if (time.get(Calendar.MINUTE) < 10){
                // Ajout devant les minutes
                // Récupération du string modifié et formaté dans le String currentTime
                currentTime = time.get(Calendar.HOUR_OF_DAY) + "h0" + time.get(Calendar.MINUTE);
            }
            else{
                currentTime = time.get(Calendar.HOUR_OF_DAY) + "h" + time.get(Calendar.MINUTE);
            }
        }
        return currentTime;
    }

    public void DisplayBatteryLevel() throws IOException {
        /*
        Le but de cette méthode est de récupérer certaines infos de la machine physique.
        Pour ce faire l'utilisation d'une librairie externe est nécessaire (JNA-4.2.2)
         */

        // Création d'un objet Kernel32.SYSTEM_POWER_STATUS permettant de récupérer les infos de la machine
        Kernel32.SYSTEM_POWER_STATUS batteryStatus = new Kernel32.SYSTEM_POWER_STATUS();
        Kernel32.INSTANCE.GetSystemPowerStatus(batteryStatus);
        // Récupération de toutes les infos de l'objet batteryStatus
        info_battery = batteryStatus.toString();
        // Création d'un tableau de string pour pouvoir travailler sur chaque infos séparément
        String[] arrOfStr = info_battery.split("\n");
        // Récupération du texte du niveau de batterie en pourcent
        percentBatteryText = arrOfStr[0];
        // Récupération du texte disant si la batterie est en charge ou non
        statusBattery = arrOfStr[1];
        // Préparation du string pour afficher uniquement le pourcentage de la batterie sans le signe %
        percentBatteryWithoutSymbol = "";


        // Récupération de l'entier sans le signe % du niveau de la batterie
        for (int i = 0; i<percentBatteryText.length(); i++){
            if (percentBatteryText.charAt(i)!= '%') {
                percentBatteryWithoutSymbol += percentBatteryText.charAt(i);
            }
        }
        // Parse en int pour permettre de travailler sur les images
        valuePercent = Integer.parseInt(percentBatteryWithoutSymbol);

        // Si le status de la batterie est "online" ou "en charge"
        if (statusBattery.equals("Online")){
            // l'image du niveau de la batterie devient celle de "load"
            img = ImageIO.read(new File("battery_pics/battery_load.png"));
        }
        else{
            // Si le niveau de batterie est entre [100 et 75[
            if (valuePercent <= 100 && valuePercent > 75){
                // l'image du niveau de batterie devient celle de "full"
                img = ImageIO.read(new File("battery_pics/battery_full.png"));
            }
            // Si le niveau de batterie est entre [75 et 50[
            else if (valuePercent <= 75 && valuePercent > 50){
                // l'image du niveau de batterie devient celle de "3/4"
                img = ImageIO.read(new File("battery_pics/battery_3_4.png"));
            }
            // Si le niveau de batterie est entre [50 et 25[
            else if (valuePercent <= 50 && valuePercent > 25){
                // l'image du niveau de batterie devient celle de "low"
                img = ImageIO.read(new File("battery_pics/battery_low.png"));
            }
            // Si le niveau de batterie est entre [25 et 0[
            else if (valuePercent <= 25 && valuePercent > 0){
                // l'image du niveau de batterie devient celle de "alert"
                img = ImageIO.read(new File("battery_pics/battery_alert.png"));
            }
        }

        // Création d'une ImageIcon contenant l'image du niveau de batterie
        ImageIcon icon = new ImageIcon(img);

        // Récupération dans le label percentDisplay du pourcentage de la batterie
        percentDisplay.setText(percentBatteryText);
        // Ajout de l'icon correspondant à l'image du niveau de batterie au label batteryDisplay
        batteryDisplay.setIcon(icon);
    }
}
