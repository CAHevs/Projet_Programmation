import javax.swing.*;

public class ImagePanel extends JPanel {
}
