import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class AlwaysOnDisplay extends JFrame {

    private JPanel panelBottom = new PanelBottom();

    private ImageIcon onIcon = new ImageIcon("onIcon2.PNG");
    private JButton on = new JButton(onIcon);

    AlwaysOnDisplay()throws IOException {
        setUndecorated(true);
        setSize(480, 800);

        setBackground(Color.BLACK);
        getContentPane().setBackground(Color.BLACK);

        Clock clock = new Clock();
        getContentPane().add(clock, BorderLayout.CENTER);
        clock.start();

        SwitchOn switchOn = new SwitchOn();
        on.addActionListener(switchOn);

        on.setBorderPainted(false);
        on.setContentAreaFilled(false);
        on.setFocusPainted(false);
        on.setOpaque(false);

        panelBottom.setBackground(Color.BLACK);
        panelBottom.add(on);
        add(panelBottom, BorderLayout.SOUTH);


    }

    class SwitchOn implements ActionListener {
        /**
         * @param e
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                LockScreen ls = new LockScreen();
                ls.setVisible(true);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            dispose();


            //System.exit(0);

        }
    }

    public static void main(String args[]) {
        AlwaysOnDisplay test = null;
        try {
            test = new AlwaysOnDisplay();
        } catch (IOException e) {
            e.printStackTrace();
        }

        test.setVisible(true);

    }


}
