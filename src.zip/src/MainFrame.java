import net.miginfocom.swing.MigLayout;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.awt.event.*;
import java.text.*;
import java.awt.image.*;
import java.time.chrono.ChronoZonedDateTime;
import java.util.Timer;

/**
 *Ecran d'accueil du smartphone
 * Les boutons ouvrent les applications "Contacts", "Gallerie" et "Jeux"
 *
 */

// Création de la JFrame de l'écran d'accueil
public class MainFrame extends JFrame {

    //Création des différentes zones de l'écran
    //Reprend la classe PanelTop pour la barre en haut de l'écran
    private PanelTop panelTop = new PanelTop();
    //Reprend la classe Background pour afficher une image en fond d'écran
    private Background myBG = new Background();
    //Création d'une zone centrale où sont affichés les boutons des apps
    private JLabel apps = new JLabel();
    //Création d'un panel contenant les boutons de fonctionalités pour le bas de l'écran
    private JPanel panelBottom = new PanelBottom();



    // Création des icônes pour les boutons de l'écran
    private ImageIcon contactIcon = new ImageIcon("Contacts.png");
    private ImageIcon galleryIcon = new ImageIcon("Gallery.png");
    private ImageIcon gameIcon = new ImageIcon("Game.png");
    private ImageIcon homeIcon = new ImageIcon("ShutDown.png");
    private ImageIcon lockIcon = new ImageIcon("Lock.png");

    //Création des boutons avec l'icône correspondante
    private JButton contacts = new JButton(contactIcon);
    private JButton gallery = new JButton(galleryIcon);
    private JButton game = new JButton(gameIcon);
    protected JButton home = new JButton(homeIcon);
    protected JButton lock = new JButton(lockIcon);

    private MainFrame parentFrame;

    //Création de la JFrame d'écran d'accueil
    public MainFrame() throws IOException {
        //Définition de la taille de la frame
        setSize(480, 800);
        //Suppression du cadre de la fenêtre Java
        setUndecorated(true);

        this.parentFrame = parentFrame;

        //Changement du Layout du PanelTop
        panelTop.setLayout(new GridLayout(1, 3));





        //Changement du Layout de la zone des apps
        apps.setLayout(new MigLayout());
        apps.setIcon(myBG.getBackground());

        changeApp changeAppAction = new changeApp();

        contacts.setBorderPainted(false);
        contacts.setContentAreaFilled(false);
        contacts.setFocusPainted(false);
        contacts.setOpaque(false);
        contacts.addActionListener(changeAppAction);

        gallery.setBorderPainted(false);
        gallery.setContentAreaFilled(false);
        gallery.setFocusPainted(false);
        gallery.setOpaque(false);
        gallery.addActionListener(changeAppAction);

        game.setBorderPainted(false);
        game.setContentAreaFilled(false);
        game.setFocusPainted(false);
        game.setOpaque(false);
        game.addActionListener(changeAppAction);


        apps.add(contacts);
        apps.add(gallery);
        apps.add(game, "wrap");


        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        lock.setBorderPainted(false);
        lock.setContentAreaFilled(false);
        lock.setFocusPainted(false);
        lock.setOpaque(false);

        Lock lockScreen = new Lock();
        lock.addActionListener(lockScreen);


        Close close = new Close();
        home.addActionListener(close);

        panelBottom.add(home);
        panelBottom.add(lock);
        panelBottom.setBackground(Color.BLACK);

        add(panelTop, BorderLayout.NORTH);
        add(apps);
        add(panelBottom, BorderLayout.SOUTH);

    }



    public class changeApp implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getSource() == contacts){
                try {
                    ContactFrame contactFrame = new ContactFrame();
                    contactFrame.setVisible(true);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

            if(e.getSource() == game){
                try {
                    PixelArtGame pixelArtGame = new PixelArtGame();
                    pixelArtGame.setVisible(true);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

            if (e.getSource() == gallery){
                try {
                   Gallery gallery = new Gallery();
                    gallery.setVisible(true);
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }

            dispose();
        }
    }

    /**
     *
     */
    class Close implements ActionListener {

        /**
         * @param e
         */
        public void actionPerformed(ActionEvent e){

            System.exit(0);

        }
    }

    class Lock implements ActionListener{
        /**
         * @param e
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                AlwaysOnDisplay aod = new AlwaysOnDisplay();
                aod.setVisible(true);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            dispose();
        }
    }

}