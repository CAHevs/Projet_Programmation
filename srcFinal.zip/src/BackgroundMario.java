import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class BackgroundMario {
    private BufferedImage bg;
    private ImageIcon imagebg;


    public BackgroundMario() throws IOException {
        bg = ImageIO.read(new File("BackgroundMario.jpg"));
        imagebg = new ImageIcon(bg);
    }
    public ImageIcon getBackground(){
        return imagebg;
    }
}
