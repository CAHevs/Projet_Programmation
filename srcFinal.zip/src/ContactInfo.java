import net.miginfocom.swing.MigLayout;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Scanner;

public class ContactInfo extends JDialog {

    private boolean newUser = false;

    private PanelTop panelTop = new PanelTop();

    private File contact;

    private JPanel panelInfo = new JPanel(new GridLayout(0,1));
    private JPanel panelName = new JPanel();
    private JPanel panelFirstName = new JPanel();
    private JPanel panelTel = new JPanel();

    private JLabel lblname = new JLabel("Nom : ", SwingConstants.LEFT);
    private JTextField txtName;

    private JLabel lblfirstName = new JLabel("Prénom : ", SwingConstants.LEFT);
    private JTextField txtFirstName;

    private JLabel lblTel = new JLabel("Téléphone : ", SwingConstants.LEFT);
    private JTextField txtTel;

    private JButton modify = new JButton("Edit");
    private JButton save = new JButton("Save");
    private JButton delete = new JButton("Delete");

    private String imgContact;
    private JButton iconContact = new JButton();

    private Frame parentFrame;

    private ImageIcon backIcon = new ImageIcon("Back.png");
    private ImageIcon homeIcon = new ImageIcon("Home.png");

    protected JButton back = new JButton(backIcon);
    protected JButton home = new JButton(homeIcon);
    private JPanel panelBottom = new PanelBottom();



    public ContactInfo(File contact, Frame parentFrame) throws IOException {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(480,800);
        setUndecorated(true);
        getContentPane().setBackground(Color.BLACK);

        imgContact = getImageContact(contact);

        this.parentFrame = parentFrame;

        modifiyContact action = new modifiyContact();

        modify.addActionListener(action);
        modify.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        modify.setBackground(Color.BLACK);
        modify.setForeground(Color.white);
        modify.setPreferredSize(new Dimension(400, 20));
        save.addActionListener(action);
        save.setPreferredSize(new Dimension(400, 20));
        save.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        save.setBackground(Color.BLACK);
        save.setForeground(Color.WHITE);
        save.setVisible(false);
        delete.addActionListener(action);
        delete.setPreferredSize(new Dimension(400, 20));
        delete.setBackground(Color.BLACK);
        delete.setForeground(Color.WHITE);
        delete.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));

        panelInfo.setLayout(new MigLayout());

        this.contact = contact;

        txtName = new JTextField(getCName(contact), 20);
        txtName.setEditable(false);
        txtName.setBorder(null);

        txtFirstName = new JTextField(getCFirstName(contact), 20);
        txtFirstName.setEditable(false);
        txtFirstName.setBorder(null);

        txtTel = new JTextField(getCTel(contact), 10);
        txtTel.setEditable(false);
        txtTel.setBorder(null);

        ImageIcon contactImageraw = null;
        try{
            contactImageraw = new ImageIcon(getImageContact(contact));
        }catch(Exception e){
            contactImageraw = new ImageIcon("contact/default_icon.png");
        }

        iconContact.setIcon(getScaledImage(contactImageraw,100,100));
        iconContact.setBorderPainted(false);
        iconContact.setContentAreaFilled(false);
        iconContact.setFocusPainted(false);
        iconContact.setOpaque(false);

        panelName.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelName.add(lblname);
        panelName.add(txtName);
        panelName.setPreferredSize(new Dimension(400, 20));
        panelFirstName.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelFirstName.add(lblfirstName);
        panelFirstName.add(txtFirstName);
        panelFirstName.setPreferredSize(new Dimension(400, 20));
        panelTel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelTel.add(lblTel);
        panelTel.add(txtTel);
        panelTel.setPreferredSize(new Dimension(400, 20));

        panelInfo.add(iconContact, "wrap");
        panelInfo.add(panelName, "wrap");
        panelInfo.add(panelFirstName, "wrap");
        panelInfo.add(panelTel, "wrap");
        panelInfo.add(modify, BorderLayout.SOUTH);
        panelInfo.add(save, BorderLayout.SOUTH);
        panelInfo.add(delete, BorderLayout.SOUTH);
        panelInfo.setBackground(Color.BLACK);

        panelBottom.add(home);
        panelBottom.add(back);
        panelBottom.setBackground(Color.BLACK);

        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Back goBack = new Back();
        back.addActionListener(goBack);

        Home goHome = new Home();
        home.addActionListener(goHome);

        add(panelInfo, BorderLayout.CENTER);
        add(panelTop, BorderLayout.NORTH);
        add(panelBottom, BorderLayout.SOUTH);
    }

    public ContactInfo(Frame parentFrame) throws IOException {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(480,800);
        setUndecorated(true);
        getContentPane().setBackground(Color.BLACK);

        this.parentFrame = parentFrame;

        newUser = true;

        modifiyContact action = new modifiyContact();

        iconContact.setIcon(new ImageIcon("contact/default_icon.png"));
        iconContact.setBorderPainted(false);
        iconContact.setContentAreaFilled(false);
        iconContact.setFocusPainted(false);
        iconContact.setOpaque(false);
        iconContact.addActionListener(action);


        modify.addActionListener(action);
        modify.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        modify.setBackground(Color.BLACK);
        modify.setForeground(Color.WHITE);
        modify.setPreferredSize(new Dimension(400, 20));
        modify.setVisible(false);
        save.addActionListener(action);
        save.setPreferredSize(new Dimension(400, 20));
        save.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        save.setBackground(Color.BLACK);
        save.setForeground(Color.WHITE);
        save.setVisible(true);
        delete.addActionListener(action);
        delete.setPreferredSize(new Dimension(400, 20));
        delete.setBackground(Color.BLACK);
        delete.setForeground(Color.WHITE);
        delete.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));


        panelInfo.setLayout(new MigLayout());

        txtName = new JTextField(20);
        txtName.setBorder(null);

        txtFirstName = new JTextField(20);
        txtFirstName.setBorder(null);

        txtTel = new JTextField(10);
        txtTel.setBorder(null);

        panelName.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelName.add(lblname);
        panelName.add(txtName);
        panelName.setPreferredSize(new Dimension(400, 20));
        panelFirstName.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelFirstName.add(lblfirstName);
        panelFirstName.add(txtFirstName);
        panelFirstName.setPreferredSize(new Dimension(400, 20));
        panelTel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelTel.add(lblTel);
        panelTel.add(txtTel);
        panelTel.setPreferredSize(new Dimension(400, 20));


        panelInfo.add(iconContact, "wrap");
        panelInfo.add(panelName, "wrap");
        panelInfo.add(panelFirstName, "wrap");
        panelInfo.add(panelTel, "wrap");
        panelInfo.add(modify, BorderLayout.SOUTH);
        panelInfo.add(save, BorderLayout.SOUTH);
        panelInfo.setBackground(Color.BLACK);

        panelBottom.add(home);
        panelBottom.add(back);
        panelBottom.setBackground(Color.BLACK);

        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Back goBack = new Back();
        back.addActionListener(goBack);

        Home goHome = new Home();
        home.addActionListener(goHome);

        add(panelInfo, BorderLayout.CENTER);
        add(panelTop, BorderLayout.NORTH);
        add(panelBottom, BorderLayout.SOUTH);
    }

    class Home implements  ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            MainFrame mf = null;
            try {
                mf = new MainFrame();
                mf.setVisible(true);

            } catch (IOException ex) {
                ex.printStackTrace();
            }
            dispose();
        }
    }

    class Back implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e){

            try {
                parentFrame = new ContactFrame();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            parentFrame.setVisible(true);
            parentFrame.revalidate();

            dispose();
        }
    }

    private String getCName(File contact) throws FileNotFoundException {
        String contactName = "";

        contactName = getPartContact(contact, 0);

        return contactName;
    }

    private String getCFirstName(File contact) throws FileNotFoundException {

        String contactFirstName = "";

        contactFirstName = getPartContact(contact, 1);

        return contactFirstName;

    }

    private String getCTel(File contact) throws FileNotFoundException {
        String numTel = "";

        numTel = getPartContact(contact, 2);

        return numTel;
    }

    private String getImageContact(File contact) throws FileNotFoundException {
        String path = "";

        path = getPartContact(contact, 3);

        return path;
    }

    private String getPartContact(File contact, int idx) throws FileNotFoundException {
        String part = "";
        String next;
        int i = 0;

        Scanner s = new Scanner(contact);

        while(s.hasNext()){
            next = s.next();
            if (i == idx){
                part = next;
            }
            i++;
        }

        s.close();

        return part;
    }

    public boolean showModal(){
        setModal(true);
        setVisible(true);
        return true;
    }

    private String changeIconContact() throws IOException {
        JFileChooser fc = new JFileChooser("images");
        File source;
        String path = "";

        fc.showOpenDialog(this);

        source = new File(String.valueOf(fc.getSelectedFile()));


        path = source.getPath();

        imgContact = path;

        return path;
    }

    private ImageIcon getScaledImage(ImageIcon srcImg, int w, int h){
        Image img = srcImg.getImage();
        BufferedImage resizedImg = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImg.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img,0,0,w,h,null);
        g2.dispose();

        return new ImageIcon(resizedImg);
    }

    private class modifiyContact implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == modify){
                txtFirstName.setEditable(true);
                txtName.setEditable(true);
                txtTel.setEditable(true);
                modify.setVisible(false);
                save.setVisible(true);
                iconContact.setEnabled(true);
                iconContact.addActionListener(this);
            }
            if(e.getSource() == iconContact){
                try {
                    iconContact.setIcon(getScaledImage(new ImageIcon(changeIconContact()),100,100));
                } catch (IOException ex) {

                }
            }
            if(e.getSource() == save){
                if(checkAllField()){
                    txtName.setEditable(false);
                    txtFirstName.setEditable(false);
                    txtTel.setEditable(false);
                    modify.setVisible(true);
                    save.setVisible(false);

                    if(newUser == true){
                        String pathname = "contact/"+txtName.getText().toLowerCase()+"_"+txtFirstName.getText().toLowerCase()+".txt";

                        File file = new File(pathname);
                        try {
                            file.createNewFile();
                            contact = file;
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                    try {
                        FileWriter fw = new FileWriter(contact);
                        fw.write(getInfoContactModified());
                        fw.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    setVisible(false);
                    try {
                        parentFrame = new ContactFrame();
                        parentFrame.setVisible(true);
                        parentFrame.revalidate();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
                else{
                    Object[] options = {"OK"};
                    JOptionPane.showOptionDialog(
                            panelInfo,"Tout les champs doivent être rempli !",
                            "Error",JOptionPane.WARNING_MESSAGE,JOptionPane.WARNING_MESSAGE, null,
                            options, options[0]
                    );
                }

            }
            if(e.getSource()==delete){
                Object[] options = {"Yes", "No"};
                int n = JOptionPane.showOptionDialog(
                        panelInfo,"Êtes-vous sûr ?",
                        "Select an Option",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE, null,
                        options, options[1]
                );
                if (n == 0){
                    String pathname = "contact/"+txtFirstName.getText().toLowerCase()+"_"+txtName.getText().toLowerCase()+".txt";
                    File file = new File(pathname);
                    file.delete();
                    try {
                        parentFrame = new ContactFrame();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    parentFrame.setVisible(true);
                    parentFrame.revalidate();
                    setVisible(false);
                }
            }
        }
    }

    private String getInfoContactModified(){
        String info ="";

        info += txtName.getText() + "\n"; // Nom
        info += txtFirstName.getText() + "\n"; // Prénom
        info += txtTel.getText() + "\n"; // Téléphone



        if (imgContact==null){
            info += "contact/default_icon.png"; // Image
        }
        else {

            info += imgContact; //Image
        }

        return info;
    }

    private boolean checkAllField(){

        if(txtTel.getText().isBlank() || txtFirstName.getText().isBlank() || txtName.getText().isBlank()){
            return false;
        }

        return true;
    }
}
