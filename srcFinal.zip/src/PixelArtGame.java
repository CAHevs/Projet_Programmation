/*
Auteur : Artero Christopher
Date création : 21.05.2019
Date fin :
But : Le but est de créer un petit jeu de coloriage pixel par pixel.
      L'utilisateur aura la possibilité de choisir entre 2 modèles ou
      de dessiner de manière libre. De base le dessin est libre.
 */

import javax.swing.*;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class PixelArtGame extends JFrame {

    private int col = 20;       // Définit le nbre de colone du tableau
    private int row = 25;       // Définit le nbre de ligne du tableau

    private PanelTop panelTop = new PanelTop(); // Création du panel top
    private JPanel panelCenter = new JPanel();  // Création du panel central contenant le jeu
    private JPanel colorPanel = new JPanel();   // Création du panel contenant le JColorChooser
    private JPanel panelBottom = new JPanel();
    private Background myBG = new Background();

    private JPanel gamePanel = new JPanel(new GridLayout(row,col)); // Création du panel pour le tableau de pixel
    private JPanel panelChoixLevel = new JPanel();  // Création du panel contenant les choix du niveau

    private JButton[][] listPixels = new JButton[row][col]; // Création d'une liste de bouton pour le tableau
    private JButton btnLibre = new JButton("Reset");   // Création d'un bouton pour choisir le dessin libre
    private JButton btnMario = new JButton("Mario");  // Création d'un bouton pour choisir le dessin Mario
    private JButton btnLink = new JButton("Link");   // Création d'un bouton pour choisir le dessin Yoshi



    private ImageIcon homeIcon = new ImageIcon("Home.png");
    private ImageIcon backIcon = new ImageIcon("Back.png");

    private JButton home = new JButton(homeIcon);
    private JButton back = new JButton(backIcon);

    private JColorChooser colorChooser; // Création du JcolorChooser

    private int valueForGame;
    private Color colorForGame;
    private boolean freeArt = true;



    public PixelArtGame() throws IOException {
        // Définition du type de fermeture de la fenêtre
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        // Définition de la taille de la fenêtre
        setSize(480,800);
        setUndecorated(true);

        float h = (float) Math.random();
        float s = (float) Math.random();

        panelCenter.setBackground(Color.getHSBColor(h, s, 1));
        panelChoixLevel.setBackground(Color.getHSBColor(h, s, 1));
        colorPanel.setBackground(Color.getHSBColor(h, s, 1));


        // Instanciation du JColorChooser
        colorChooser = new JColorChooser();
        // Récupération des différentes options pour le choix des couleurs
        AbstractColorChooserPanel[] panelsColor = colorChooser.getChooserPanels();
        // Boucle permettant d'afficher uniquement la partie Swatches du JColorChooser
        for(AbstractColorChooserPanel accp : panelsColor){
            if(!accp.getDisplayName().equals("Swatches")){
                colorChooser.removeChooserPanel(accp);
            }
        }
        // Supprésion de la partie Preview du JColorChooser
        colorChooser.setPreviewPanel(new JPanel());

        // Ajout du JColorChooser au panel prévu à cet effet
        colorPanel.add(colorChooser);

        // Boucle pour la création du tableau de bouton simulant les pixels
        for (int i = 0; i<row; i++){
            for (int j = 0; j<col; j++){
                listPixels[i][j] = new JButton();
                // Supprésion du fond bleu métalisé du bouton
                listPixels[i][j].setContentAreaFilled(true);
                listPixels[i][j].setBackground(Color.WHITE);
                // Définition de la taille du bouton
                listPixels[i][j].setPreferredSize(new Dimension(20,20));
                // Ajout de l'ActionListener permettant de colorier le bouton
                listPixels[i][j].addActionListener(new PutColor(listPixels[i][j]));
                // Ajout du bouton créer dans le panel prévu pour le tableau
                gamePanel.add(listPixels[i][j]);
            }
        }

        LevelSelection lvlSelection = new LevelSelection(colorPanel, colorChooser, listPixels);
        btnMario.addActionListener(lvlSelection);
        btnMario.setBackground(Color.BLACK);
        btnMario.setForeground(Color.WHITE);
        btnLink.addActionListener(lvlSelection);
        btnLink.setBackground(Color.BLACK);
        btnLink.setForeground(Color.WHITE);
        btnLibre.addActionListener(lvlSelection);
        btnLibre.setBackground(Color.BLACK);
        btnLibre.setForeground(Color.WHITE);

        // Ajout au panel central du panel contenant le tableau et du panel contenant le JColorChooser
        panelCenter.add(gamePanel, BorderLayout.NORTH);
        panelCenter.add(colorPanel, BorderLayout.CENTER);
        // Ajout au panel central les boutons mario et link pour le choix du dessin
        panelChoixLevel.add(btnMario, BorderLayout.SOUTH);
        panelChoixLevel.add(btnLink, BorderLayout.SOUTH);
        panelChoixLevel.add(btnLibre, BorderLayout.SOUTH);

        panelCenter.add(panelChoixLevel, BorderLayout.SOUTH);

        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setOpaque(false);

        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setOpaque(false);

        Back goBack = new Back();

        home.addActionListener(goBack);
        back.addActionListener(goBack);


        panelBottom.add(home);
        panelBottom.add(back);
        panelBottom.setBackground(Color.BLACK);

        add(panelBottom, BorderLayout.SOUTH);

        // Ajout du panel top à la frame et du panel central à la frame
        add(panelTop, BorderLayout.NORTH);
        add(panelCenter, BorderLayout.CENTER);
    }

    public class LevelSelection implements ActionListener{

        private JPanel actColorPanel;
        private JColorChooser colorChooser;
        private JButton[][] newListPixel;
        private JButton[][] baseListPixel;
        private JPanel colorsChoice = new JPanel(new GridLayout(0,5));

        private JPanel panelBottom = new JPanel(new GridLayout(0,1));

        private ImageIcon homeIcon = new ImageIcon("HomeIcon.png");
        private ImageIcon backIcon = new ImageIcon("backIcon.png");

        private JButton home = new JButton(homeIcon);
        private JButton back = new JButton(backIcon);

        public LevelSelection(JPanel actColorPanel, JColorChooser colorChooser, JButton[][] newListPixel){
            this.actColorPanel = actColorPanel;
            this.colorChooser = colorChooser;
            this.newListPixel = newListPixel;
        }

        @Override
        public void actionPerformed(ActionEvent e) {


            colorsChoice.removeAll();

            actColorPanel.removeAll();

            baseListPixel = newListPixel;

            JButton[] listColor;

            for (int i = 0; i< row; i++){
                for (int j = 0; j<col; j++){
                    newListPixel[i][j].setText("");
                    newListPixel[i][j].setEnabled(true);
                    newListPixel[i][j].setBackground(Color.white);
                    newListPixel[i][j].setBorderPainted(true);
                }
            }

            if(e.getSource() == btnMario){

                btnLibre.setText("Libre");
                btnLibre.setVisible(true);
                btnLink.setVisible(true);
                btnMario.setVisible(false);



                panelCenter.setBackground(Color.getHSBColor(0, 0.7f, 1));
                panelChoixLevel.setBackground(Color.getHSBColor(0, 0.7f, 1));
                colorPanel.setBackground(Color.getHSBColor(0, 0.7f, 1));
                colorsChoice.setBackground(Color.getHSBColor(0, 0.7f, 1));

                freeArt = false;

                listColor = new JButton[3];
                listColor[0] = new JButton("1");
                listColor[0].setBackground(Color.red);
                listColor[0].addActionListener(new ChangeValueColor(0, listColor[0].getBackground()));
                listColor[1] = new JButton("2");
                listColor[1].setBackground(Color.getHSBColor(34,139,34));
                listColor[1].addActionListener(new ChangeValueColor(1, listColor[1].getBackground()));
                listColor[2] = new JButton("3");
                listColor[2].setBackground(new Color(100,150,20));
                listColor[2].addActionListener(new ChangeValueColor(2, listColor[2].getBackground()));


                for (int i = 0; i<listColor.length;i++){

                    colorsChoice.add(listColor[i]);
                }

                actColorPanel.add(colorsChoice);

                for(int i = 0; i< row; i++){
                    for(int j = 0; j<col; j++){
                        newListPixel[i][j].setContentAreaFilled(true);
                        newListPixel[i][j].setMargin(new Insets(0,0,0,0));
                        newListPixel[i][j].setBackground(Color.LIGHT_GRAY);
                        newListPixel[i][j].addActionListener(new PutColor(newListPixel[i][j]));
                        switch(i){
                            default:
                                newListPixel[i][j].setEnabled(false);
                                newListPixel[i][j].setBackground(Color.white);
                                break;
                            case 2:
                                if(j == 15 || j == 16 || j == 17){
                                    newListPixel[i][j].setText("2");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 3:
                                if(j >= 8 && j<= 12){
                                    newListPixel[i][j].setText("1");
                                }
                                else if(j == 15 || j == 16 || j == 17){
                                    newListPixel[i][j].setText("2");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 4:
                                if(j >= 7 && j<=15){
                                    newListPixel[i][j].setText("1");
                                }
                                else if(j == 16 || j == 17){
                                    newListPixel[i][j].setText("2");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 5:
                                if(j == 7 || j == 8 || j == 9 || j == 12){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j == 10 || j == 11 || j == 13) {
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j == 15 || j == 16 || j == 17){
                                    newListPixel[i][j].setText("1");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 6:
                                if (j == 6 || j == 8 || j == 9 || j == 12){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j == 7 || j == 9 || j == 10 || j == 11 || j == 13 || j == 14){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j>= 15 && j<=17){
                                    newListPixel[i][j].setText("1");
                                }
                                else
                                {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 7:
                                if (j==6 || j== 8 || j == 9 || j == 13){
                                    newListPixel[i][j].setText("3");
                                } else if (j == 7 || (j >= 10 && j <= 12) || (j >= 14 && j <= 16)) {
                                    newListPixel[i][j].setText("2");
                                }
                                else if(j == 17){
                                    newListPixel[i][j].setText("1");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 8:
                                if (j == 6 || j == 7 || (j>= 12 && j<= 16)){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j >= 8 && j<=11){
                                    newListPixel[i][j].setText("2");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 9:
                                if (j >= 10 && j<= 14){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j == 15){
                                    newListPixel[i][j].setText("3");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 10:
                                if ((j >= 4 && j<=8) || (j>= 10 && j<=12) || j == 14){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j == 9 || j == 13){
                                    newListPixel[i][j].setText("1");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 11:
                                if ((j>= 3 && j<= 9) || (j>= 11 && j<= 13)){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j == 10 || j == 14){
                                    newListPixel[i][j].setText("1");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 12:
                                if (j == 2 || j == 3){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j >= 4 && j<= 9){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j >= 10 && j<= 14){
                                    newListPixel[i][j].setText("1");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 13:
                                if (j == 2 || j == 3 || j == 4){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j == 6 || j == 7 || j == 9 || j == 10 || j == 12 || j == 13 || j == 15){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 8 || j == 16 || j == 17){
                                    newListPixel[i][j].setText("3");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 14:
                                if (j == 3){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j == 5 || j == 16 || j == 17){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j >= 6 && j<= 15){
                                    newListPixel[i][j].setText("1");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 15:
                                if ((j>=4 && j<=6) || j == 16 || j == 17){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j>= 7 && j<=15){
                                    newListPixel[i][j].setText("1");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 16:
                                if (j == 3 || j == 4 || j == 5){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j>= 6 && j<= 12){
                                    newListPixel[i][j].setText("1");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 17:
                                if (j == 3){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j >= 6 && j<=9){
                                    newListPixel[i][j].setText("1");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                        }
                    }
                }

                listPixels = newListPixel;
            }
            if(e.getSource() == btnLink){

                btnLibre.setText("Libre");
                btnLibre.setVisible(true);
                btnLink.setVisible(false);
                btnMario.setVisible(true);

                panelCenter.setBackground(Color.getHSBColor(0.35f, 0.7f, 1));
                panelChoixLevel.setBackground(Color.getHSBColor(0.35f, 0.7f, 1));
                colorPanel.setBackground(Color.getHSBColor(0.35f, 0.7f, 1));
                colorsChoice.setBackground(Color.getHSBColor(0.35f, 0.7f, 1));

                freeArt = false;

                listColor = new JButton[12];
                listColor[0] = new JButton("1");
                listColor[0].setBackground(new Color(33,31,29));
                listColor[0].addActionListener(new ChangeValueColor(0, listColor[0].getBackground()));
                listColor[1] = new JButton("2");
                listColor[1].setBackground(new Color(0,92,32));
                listColor[1].addActionListener(new ChangeValueColor(1, listColor[1].getBackground()));
                listColor[2] = new JButton("3");
                listColor[2].setBackground(new Color(10,188,1));
                listColor[2].addActionListener(new ChangeValueColor(2, listColor[2].getBackground()));
                listColor[3] = new JButton("4");
                listColor[3].setBackground(new Color(210,105,30));
                listColor[3].addActionListener(new ChangeValueColor(3, listColor[3].getBackground()));
                listColor[4] = new JButton("5");
                listColor[4].setBackground(new Color(255,255,0));
                listColor[4].addActionListener(new ChangeValueColor(4, listColor[4].getBackground()));
                listColor[5] = new JButton("6");
                listColor[5].setBackground(new Color(139,69,19));
                listColor[5].addActionListener(new ChangeValueColor(5, listColor[5].getBackground()));
                listColor[6] = new JButton("7");
                listColor[6].setBackground(new Color(255,186,114));
                listColor[6].addActionListener(new ChangeValueColor(6, listColor[6].getBackground()));
                listColor[7] = new JButton("8");
                listColor[7].setBackground(new Color(78,49,0));
                listColor[7].addActionListener(new ChangeValueColor(7, listColor[7].getBackground()));
                listColor[8] = new JButton("9");
                listColor[8].setBackground(new Color(254,170,0));
                listColor[8].addActionListener(new ChangeValueColor(8, listColor[8].getBackground()));
                listColor[9] = new JButton("10");
                listColor[9].setBackground(new Color(254,213,154));
                listColor[9].addActionListener(new ChangeValueColor(9, listColor[9].getBackground()));
                listColor[10] = new JButton("11");
                listColor[10].setBackground(new Color(9,66,254));
                listColor[10].addActionListener(new ChangeValueColor(10, listColor[10].getBackground()));
                listColor[11] = new JButton("12");
                listColor[11].setBackground(new Color(255,0,0));
                listColor[11].addActionListener(new ChangeValueColor(11, listColor[11].getBackground()));


                for (int i = 0; i<listColor.length;i++){

                    colorsChoice.add(listColor[i]);
                }

                actColorPanel.add(colorsChoice);

                for (int i = 0; i<row; i++){
                    for (int j = 0; j<col; j++){
                        newListPixel[i][j].setContentAreaFilled(true);
                        newListPixel[i][j].setMargin(new Insets(0,0,0,0));
                        newListPixel[i][j].setBackground(Color.LIGHT_GRAY);
                        newListPixel[i][j].addActionListener(new PutColor(newListPixel[i][j]));

                        switch (i){
                            default :
                                newListPixel[i][j].setEnabled(false);
                                newListPixel[i][j].setBackground(Color.white);
                                break;

                            case 1:
                                if(j==7 || j == 12){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j >= 8 && j<= 11){
                                    newListPixel[i][j].setText("2");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 2:
                                if(j==6 || j==13){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 7 || j == 12){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j >= 8 && j<= 11){
                                    newListPixel[i][j].setText("3");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 3:
                                if (j == 5 || j == 14){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 6 || j == 13){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j >= 7 && j <= 12){
                                    newListPixel[i][j].setText("3");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 4:
                                if (j == 4 || j == 15){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 5 || j == 14){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j >= 6 && j<= 13){
                                    newListPixel[i][j].setText("3");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 5:
                                if (j == 4 || j == 15){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 5 || j == 14){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j == 6){
                                    newListPixel[i][j].setText("4");
                                }
                                else if (j >= 7 && j<= 12){
                                    newListPixel[i][j].setText("5");
                                }
                                else if (j == 13){
                                    newListPixel[i][j].setText("6");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 6:
                                if (j == 3 || j == 16){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 4 || j == 15){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j == 5){
                                    newListPixel[i][j].setText("4");
                                }
                                else if (j >= 6 && j <= 13){
                                    newListPixel[i][j].setText("5");
                                }
                                else if (j == 14){
                                    newListPixel[i][j].setText("6");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.WHITE);
                                }
                                break;
                            case 7:
                                if (j == 1 || j == 12 || j == 18){
                                    newListPixel[i][j].setText("4");
                                }
                                else if ( j == 2 || j == 17){
                                    newListPixel[i][j].setText("7");
                                }
                                else if (j == 3 || j == 4 || j == 15 || j == 16){
                                    newListPixel[i][j].setText("8");
                                }
                                else if (j == 5 || j == 11 || j == 13){
                                    newListPixel[i][j].setText("9");
                                }
                                else if ((j>= 6 && j<= 10) || j == 14){
                                    newListPixel[i][j].setText("5");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 8:
                                if (j == 1 || j == 18){
                                    newListPixel[i][j].setText("8");
                                }
                                else if (j == 2 || j == 3 || j == 16 || j == 17){
                                    newListPixel[i][j].setText("10");
                                }
                                else if (j == 4 || j == 6 || j == 11 || j == 13 || j == 15){
                                    newListPixel[i][j].setText("4");
                                }
                                else if (j == 5 || (j >= 7 && j <= 10) || j == 14){
                                    newListPixel[i][j].setText("5");
                                }
                                else if (j == 12){
                                    newListPixel[i][j].setText("7");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 9:
                                if (j == 2 || j == 4 || j == 5 || j == 10 || j == 17){
                                    newListPixel[i][j].setText("8");
                                }
                                else if (j == 3 || j == 11 || j == 16){
                                    newListPixel[i][j].setText("7");
                                }
                                else if (j == 6 || j == 9 || j == 14){
                                    newListPixel[i][j].setText("9");
                                }
                                else if (j == 7 || j == 8){
                                    newListPixel[i][j].setText("5");
                                }
                                else if (j == 12){
                                    newListPixel[i][j].setText("10");
                                }
                                else if (j == 13 || j == 15){
                                    newListPixel[i][j].setText("4");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.WHITE);
                                }
                                break;
                            case 10:
                                if (j == 3 || j == 8 ){
                                    newListPixel[i][j].setText("4");
                                }
                                else if (j == 4 || j == 15){
                                    newListPixel[i][j].setText("5");
                                }
                                else if (j == 5 || j == 9 || j == 16){
                                    newListPixel[i][j].setText("8");
                                }
                                else if (j == 6 || j == 7){
                                    newListPixel[i][j].setText("9");
                                }
                                else if (j == 10 || j == 13){
                                    newListPixel[i][j].setText("7");
                                }
                                else if (j == 11 || j == 12){
                                    newListPixel[i][j].setText("10");
                                }
                                else if (j == 14){
                                    newListPixel[i][j].setText("1");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 11:
                                if (j == 3 || j == 6 || j == 16){
                                    newListPixel[i][j].setText("1");
                                }
                                else if ( j == 4 || j == 15){
                                    newListPixel[i][j].setText("5");
                                }
                                else if (j == 5 || j == 7){
                                    newListPixel[i][j].setText("4");
                                }
                                else if (j == 8 || j == 12 || j == 13){
                                    newListPixel[i][j].setText("8");
                                }
                                else if (j == 9 || j == 11){
                                    newListPixel[i][j].setText("7");
                                }
                                else if (j == 10 || j == 14){
                                    newListPixel[i][j].setText("10");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 12:
                                if (j == 3 || j == 16){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 4 || j == 15){
                                    newListPixel[i][j].setText("9");
                                }
                                else if (j == 5){
                                    newListPixel[i][j].setText("4");
                                }
                                else if (j == 7 || j == 12){
                                    newListPixel[i][j].setText("11");
                                }
                                else if (j == 8 || j == 11){
                                    newListPixel[i][j].setText("8");
                                }
                                else if (j == 9 || j == 10 || j == 14){
                                    newListPixel[i][j].setText("10");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 13:
                                if (j == 4 || j == 5 || j == 14 || j == 15){
                                    newListPixel[i][j].setText("1");
                                }
                                else if ( j == 6 || j == 9 || j == 10 || j == 13){
                                    newListPixel[i][j].setText("10");
                                }
                                else if (j == 7 || j == 12){
                                    newListPixel[i][j].setText("11");
                                }
                                else {
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 14:
                                if (j == 5 || j == 14){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 6 || j == 13){
                                    newListPixel[i][j].setText("4");
                                }
                                else if (j >= 7 && j <= 12){
                                    newListPixel[i][j].setText("10");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 15:
                                if (j == 4 || j == 15){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 5 || j == 14){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j == 6||j == 7 || j == 12 || j == 13){
                                    newListPixel[i][j].setText("8");
                                }
                                else if ( j >= 8 && j<= 11){
                                    newListPixel[i][j].setText("7");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 16:
                                if ( j == 3 || j == 16){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 4 || j == 5 || j == 14 || j == 15){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j>= 6 && j<=13){
                                    newListPixel[i][j].setText("2");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 17:
                                if ( j == 2 || j == 5 || j == 6 || j == 13 || j == 14 || j == 17){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 3 || j == 4 || j == 15 || j == 16){
                                    newListPixel[i][j].setText("10");
                                }
                                else if (j >= 7 && j <= 12){
                                    newListPixel[i][j].setText("2");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 18:
                                if (j == 2 || j == 7 || j == 8 || j == 11 || j == 12 || j == 17){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 3 || j == 16){
                                    newListPixel[i][j].setText("7");
                                }
                                else if ( j == 4 || j == 15){
                                    newListPixel[i][j].setText("10");
                                }
                                else if (j == 5 || j == 14){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j == 6 || j == 13){
                                    newListPixel[i][j].setText("3");
                                }
                                else if ( j == 9 || j == 10){
                                    newListPixel[i][j].setText("5");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 19:
                                if (j == 3 || j == 4 || j == 5 || j == 14 || j == 15 || j == 16){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 6 || j == 7 || j == 12 || j == 13){
                                    newListPixel[i][j].setText("3");
                                }
                                else if (j == 8 || j == 11){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j == 9 || j == 10){
                                    newListPixel[i][j].setText("5");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 20:
                                if ( j == 5 || j == 6 || j == 13 || j == 14){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 7 || j == 12){
                                    newListPixel[i][j].setText("2");
                                }
                                else if (j >= 8 && j <= 11){
                                    newListPixel[i][j].setText("3");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 21:
                                if (j == 4 || (j >= 7 && j <= 12) || j == 15){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 5 || j == 6 || j == 13 || j == 14){
                                    newListPixel[i][j].setText("12");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 22:
                                if (j == 4 || j == 8 || j == 11 || j == 15){
                                    newListPixel[i][j].setText("1");
                                }
                                else if (j == 5 || j == 6 || j == 7 || j == 12 || j == 13 || j == 14){
                                    newListPixel[i][j].setText("12");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                            case 23:
                                if ( (j>= 5 && j <=7) || (j >= 12 && j <= 14)){
                                    newListPixel[i][j].setText("1");
                                }
                                else{
                                    newListPixel[i][j].setEnabled(false);
                                    newListPixel[i][j].setBackground(Color.white);
                                }
                                break;
                        }
                    }
                }
            }
            if(e.getSource() == btnLibre){
                btnLibre.setText("Reset");
                btnLibre.setVisible(true);
                btnLink.setVisible(true);
                btnMario.setVisible(true);

                float h = (float) Math.random();
                float s = (float) Math.random();

                panelCenter.setBackground(Color.getHSBColor(h, s, 1));
                panelChoixLevel.setBackground(Color.getHSBColor(h, s, 1));
                colorPanel.setBackground(Color.getHSBColor(h, s, 1));
                actColorPanel.add(colorChooser);
                freeArt = true;

                listPixels = baseListPixel;
            }
        }
    }

    public class ChangeValueColor implements ActionListener{

        private int value;
        private Color colorSelected;

        public ChangeValueColor(int value, Color colorSlected){
            this.value = value;
            this.colorSelected = colorSlected;
        }

        @Override
        public void actionPerformed(ActionEvent e) {

            valueForGame = value;
            colorForGame = colorSelected;
        }
    }

    public class PutColor implements ActionListener{

        private JColorChooser newColor;
        private JButton actualButton;

        public PutColor(JButton actualButton){
            this.actualButton = actualButton;
        }


        @Override
        public void actionPerformed(ActionEvent e) {

            if (freeArt){
                actualButton.setBackground(colorChooser.getColor());
                actualButton.setContentAreaFilled(true);
                actualButton.setBorderPainted(false);
            }
            else{
                if (actualButton.getText().equals(String.valueOf(valueForGame+1))){
                    actualButton.setBackground(colorForGame);
                    actualButton.setContentAreaFilled(true);
                    actualButton.setBorderPainted(false);
                    actualButton.setEnabled(false);
                    actualButton.setText("");
                }
                else{
                    actualButton.setBackground(colorForGame);
                }
            }
        }
    }

    class Back implements ActionListener {
        public void actionPerformed(ActionEvent e){
            MainFrame mf = null;
            try {
                mf = new MainFrame();
                mf.setVisible(true);

            } catch (IOException ex) {
                ex.printStackTrace();
            }
            dispose();
        }
    }
}
