import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {

        LockScreen ls = new LockScreen();

        ls.setVisible(true);




    }
}
